import React, { useState } from 'react';
import MainHeader from '../../components/ui/MainHeader';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const Library = () => {
  const [selectedSection, setSelectedSection] = useState('history');

  // Mock user data
  const mockUser = {
    name: "Alex Johnson",
    email: "alex.johnson@example.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"
  };

  const sections = [
    { id: 'history', label: 'History', icon: 'Clock' },
    { id: 'watchLater', label: 'Watch Later', icon: 'Clock3' },
    { id: 'likedVideos', label: 'Liked Videos', icon: 'ThumbsUp' },
    { id: 'playlists', label: 'Playlists', icon: 'ListVideo' },
  ];

  // Mock library data
  const mockLibraryData = {
    history: [
      {
        id: "h1",
        title: "Advanced React Patterns - Complete Tutorial",
        thumbnail: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop",
        duration: 2456,
        views: 1234567,
        channel: {
          name: "CodeMaster Pro",
          avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&h=400&fit=crop&crop=face",
          isVerified: true
        },
        watchedAt: "2024-01-16T10:30:00Z",
        progress: 75 // percentage watched
      },
      {
        id: "h2",
        title: "Epic Gaming Montage - Best Moments 2024",
        thumbnail: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400&h=225&fit=crop",
        duration: 654,
        views: 2456789,
        channel: {
          name: "Gaming Central",
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
          isVerified: true
        },
        watchedAt: "2024-01-15T20:15:00Z",
        progress: 100
      }
    ],
    watchLater: [
      {
        id: "wl1",
        title: "Machine Learning Explained Simply",
        thumbnail: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=225&fit=crop",
        duration: 1834,
        views: 987654,
        channel: {
          name: "AI Academy",
          avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
          isVerified: true
        },
        addedAt: "2024-01-14T16:20:00Z"
      },
      {
        id: "wl2",
        title: "Photography Tips for Beginners",
        thumbnail: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&h=225&fit=crop",
        duration: 1245,
        views: 567890,
        channel: {
          name: "Photo Pro",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
          isVerified: false
        },
        addedAt: "2024-01-13T12:45:00Z"
      }
    ],
    likedVideos: [
      {
        id: "lv1",
        title: "Relaxing Nature Sounds - 1 Hour",
        thumbnail: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&h=225&fit=crop",
        duration: 3600,
        views: 3456789,
        channel: {
          name: "Nature Sounds",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
          isVerified: false
        },
        likedAt: "2024-01-12T09:30:00Z"
      }
    ],
    playlists: [
      {
        id: "pl1",
        title: "My Learning Playlist",
        thumbnail: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop",
        videoCount: 15,
        privacy: "Private",
        updatedAt: "2024-01-16T10:00:00Z",
        description: "Collection of educational videos for skill development"
      },
      {
        id: "pl2",
        title: "Favorite Music Videos",
        thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=225&fit=crop",
        videoCount: 28,
        privacy: "Public",
        updatedAt: "2024-01-15T18:30:00Z",
        description: "My all-time favorite music videos and performances"
      }
    ]
  };

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
  };

  const formatViews = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000)?.toFixed(1)}M views`;
    }
    if (views >= 1000) {
      return `${(views / 1000)?.toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInHours = Math.floor((now - time) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  const handleVideoClick = (videoId) => {
    window.location.href = `/video-player?v=${videoId}`;
  };

  const handlePlaylistClick = (playlistId) => {
    console.log(`Open playlist: ${playlistId}`);
  };

  const renderContent = () => {
    const data = mockLibraryData?.[selectedSection];
    
    if (!data || data?.length === 0) {
      return (
        <div className="text-center py-12">
          <Icon name="FileX" size={48} className="mx-auto text-text-secondary mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">
            Nothing here yet
          </h3>
          <p className="text-text-secondary">
            {selectedSection === 'history' && "Videos you watch will appear here"}
            {selectedSection === 'watchLater' && "Save videos to watch them later"}
            {selectedSection === 'likedVideos' && "Like videos to save them here"}
            {selectedSection === 'playlists' && "Create playlists to organize your videos"}
          </p>
        </div>
      );
    }

    if (selectedSection === 'playlists') {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
          {data?.map((playlist) => (
            <div
              key={playlist?.id}
              className="group cursor-pointer"
              onClick={() => handlePlaylistClick(playlist?.id)}
            >
              <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                <img
                  src={playlist?.thumbnail}
                  alt={playlist?.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
                
                <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
                  {playlist?.videoCount} videos
                </div>

                <div className="absolute top-2 right-2">
                  <Icon 
                    name={playlist?.privacy === 'Private' ? 'Lock' : 'Globe'} 
                    size={16} 
                    className="text-white" 
                  />
                </div>
              </div>

              <div className="mt-3">
                <h3 className="font-medium text-sm text-foreground line-clamp-2 group-hover:text-primary transition-colors duration-200">
                  {playlist?.title}
                </h3>
                
                <p className="text-xs text-text-secondary mt-1">
                  {playlist?.privacy} • Updated {formatTimeAgo(playlist?.updatedAt)}
                </p>
              </div>
            </div>
          ))}
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {data?.map((item) => (
          <div
            key={item?.id}
            className="flex gap-4 p-4 rounded-lg hover:bg-muted cursor-pointer transition-colors duration-200"
            onClick={() => handleVideoClick(item?.id)}
          >
            {/* Thumbnail */}
            <div className="relative aspect-video w-48 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
              <img
                src={item?.thumbnail}
                alt={item?.title}
                className="w-full h-full object-cover"
              />
              
              <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
                {formatDuration(item?.duration)}
              </div>

              {/* Progress Bar for History */}
              {selectedSection === 'history' && item?.progress && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-black bg-opacity-50">
                  <div 
                    className="h-full bg-primary transition-all duration-300"
                    style={{ width: `${item?.progress}%` }}
                  />
                </div>
              )}
            </div>

            {/* Video Info */}
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-foreground line-clamp-2 mb-2">
                {item?.title}
              </h3>
              
              <div className="flex items-center gap-2 mb-2">
                <img
                  src={item?.channel?.avatar}
                  alt={item?.channel?.name}
                  className="w-6 h-6 rounded-full object-cover"
                />
                <span className="text-sm text-text-secondary">
                  {item?.channel?.name}
                </span>
                {item?.channel?.isVerified && (
                  <Icon name="CheckCircle" size={12} className="text-primary" />
                )}
              </div>
              
              <div className="flex items-center gap-2 text-sm text-text-secondary mb-2">
                <span>{formatViews(item?.views)}</span>
              </div>

              <div className="text-xs text-text-secondary">
                {selectedSection === 'history' && `Watched ${formatTimeAgo(item?.watchedAt)}`}
                {selectedSection === 'watchLater' && `Added ${formatTimeAgo(item?.addedAt)}`}
                {selectedSection === 'likedVideos' && `Liked ${formatTimeAgo(item?.likedAt)}`}
              </div>
            </div>

            {/* Action Button */}
            <div className="flex-shrink-0 self-center">
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e?.stopPropagation();
                  console.log(`Remove from ${selectedSection}:`, item?.id);
                }}
              >
                <Icon name="X" size={16} />
              </Button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} user={mockUser} />
      
      <main className="pt-14 md:pt-16">
        {/* Header */}
        <div className="border-b border-border">
          <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
            <div className="flex items-center gap-3 mb-6">
              <Icon name="BookOpen" size={32} className="text-primary" />
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">Library</h1>
            </div>

            {/* Section Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
              {sections?.map((section) => (
                <Button
                  key={section?.id}
                  variant={selectedSection === section?.id ? "primary" : "ghost"}
                  onClick={() => setSelectedSection(section?.id)}
                  className="whitespace-nowrap flex-shrink-0"
                >
                  <Icon name={section?.icon} size={16} className="mr-2" />
                  {section?.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default Library;