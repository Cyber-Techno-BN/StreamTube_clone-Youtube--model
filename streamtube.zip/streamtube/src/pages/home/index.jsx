import React, { useState, useEffect } from 'react';
import MainHeader from '../../components/ui/MainHeader';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const Home = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [videos, setVideos] = useState([]);

  // Mock user data
  const mockUser = {
    name: "Alex Johnson",
    email: "alex.johnson@example.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"
  };

  // Categories for filtering
  const categories = [
    'All', 'Gaming', 'Music', 'Sports', 'News', 'Entertainment', 
    'Education', 'Science & Technology', 'Fashion & Beauty', 'Travel & Events'
  ];

  // Mock video data for home feed
  const mockVideos = [
    {
      id: "v1",
      title: "10 JavaScript Tips Every Developer Should Know in 2024",
      thumbnail: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop",
      duration: 892,
      views: 1234567,
      publishedAt: "2024-01-15T10:30:00Z",
      channel: {
        id: "c1",
        name: "CodeMaster Pro",
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "850K"
      },
      category: "Education"
    },
    {
      id: "v2",
      title: "Epic Gaming Montage - Best Moments of 2024",
      thumbnail: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400&h=225&fit=crop",
      duration: 654,
      views: 2456789,
      publishedAt: "2024-01-14T16:45:00Z",
      channel: {
        id: "c2",
        name: "Gaming Central",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "2.1M"
      },
      category: "Gaming"
    },
    {
      id: "v3",
      title: "Latest Pop Hits 2024 - 1 Hour Mix",
      thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=225&fit=crop",
      duration: 3600,
      views: 5678901,
      publishedAt: "2024-01-13T12:20:00Z",
      channel: {
        id: "c3",
        name: "Music Vibes",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "3.2M"
      },
      category: "Music"
    },
    {
      id: "v4",
      title: "Breaking: Major Tech Announcement Changes Everything",
      thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=225&fit=crop",
      duration: 456,
      views: 987654,
      publishedAt: "2024-01-12T09:15:00Z",
      channel: {
        id: "c4",
        name: "Tech News Daily",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "1.5M"
      },
      category: "News"
    },
    {
      id: "v5",
      title: "Amazing Wildlife Documentary - Life in the Amazon",
      thumbnail: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&h=225&fit=crop",
      duration: 2847,
      views: 3456789,
      publishedAt: "2024-01-11T14:30:00Z",
      channel: {
        id: "c5",
        name: "Nature Explorer",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
        isVerified: false,
        subscribers: "925K"
      },
      category: "Entertainment"
    },
    {
      id: "v6",
      title: "How to Build Your First React App - Complete Tutorial",
      thumbnail: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=225&fit=crop",
      duration: 1234,
      views: 876543,
      publishedAt: "2024-01-10T11:00:00Z",
      channel: {
        id: "c1",
        name: "CodeMaster Pro",
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "850K"
      },
      category: "Education"
    }
  ];

  useEffect(() => {
    // Filter videos based on selected category
    if (selectedCategory === 'All') {
      setVideos(mockVideos);
    } else {
      setVideos(mockVideos?.filter(video => video?.category === selectedCategory));
    }
  }, [selectedCategory]);

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
  };

  const formatViews = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000)?.toFixed(1)}M views`;
    }
    if (views >= 1000) {
      return `${(views / 1000)?.toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const formatTimeAgo = (publishedAt) => {
    const now = new Date();
    const published = new Date(publishedAt);
    const diffInHours = Math.floor((now - published) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  const handleVideoClick = (videoId) => {
    // Navigate to video player
    window.location.href = `/video-player?v=${videoId}`;
  };

  const handleChannelClick = (channelId) => {
    // Navigate to channel profile
    window.location.href = `/channel-profile?c=${channelId}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} user={mockUser} />
      <main className="pt-14 md:pt-16">
        {/* Category Filter */}
        <div className="sticky top-14 md:top-16 bg-background border-b border-border z-10">
          <div className="flex items-center gap-3 px-4 md:px-6 py-3 overflow-x-auto scrollbar-hide">
            {categories?.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "primary" : "secondary"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="whitespace-nowrap flex-shrink-0"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Video Grid */}
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
            {videos?.map((video) => (
              <div
                key={video?.id}
                className="group cursor-pointer"
                onClick={() => handleVideoClick(video?.id)}
              >
                {/* Thumbnail */}
                <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                  <img
                    src={video?.thumbnail}
                    alt={video?.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                  
                  {/* Duration */}
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
                    {formatDuration(video?.duration)}
                  </div>
                </div>

                {/* Video Info */}
                <div className="flex gap-3 mt-3">
                  {/* Channel Avatar */}
                  <button
                    onClick={(e) => {
                      e?.stopPropagation();
                      handleChannelClick(video?.channel?.id);
                    }}
                    className="flex-shrink-0"
                  >
                    <img
                      src={video?.channel?.avatar}
                      alt={video?.channel?.name}
                      className="w-9 h-9 rounded-full object-cover"
                    />
                  </button>

                  {/* Video Details */}
                  <div className="min-w-0 flex-1">
                    <h3 className="font-medium text-sm text-foreground line-clamp-2 group-hover:text-primary transition-colors duration-200">
                      {video?.title}
                    </h3>
                    
                    <button
                      onClick={(e) => {
                        e?.stopPropagation();
                        handleChannelClick(video?.channel?.id);
                      }}
                      className="flex items-center gap-1 mt-1 text-text-secondary hover:text-foreground transition-colors duration-200"
                    >
                      <span className="text-sm">{video?.channel?.name}</span>
                      {video?.channel?.isVerified && (
                        <Icon name="CheckCircle" size={12} className="text-primary" />
                      )}
                    </button>
                    
                    <div className="flex items-center gap-1 mt-1 text-xs text-text-secondary">
                      <span>{formatViews(video?.views)}</span>
                      <span>•</span>
                      <span>{formatTimeAgo(video?.publishedAt)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Load More Button */}
          {videos?.length > 0 && (
            <div className="flex justify-center mt-8">
              <Button variant="outline" onClick={() => console.log('Load more videos')}>
                <Icon name="RefreshCw" size={16} className="mr-2" />
                Load More Videos
              </Button>
            </div>
          )}

          {/* No Videos Message */}
          {videos?.length === 0 && (
            <div className="text-center py-12">
              <Icon name="Film" size={48} className="mx-auto text-text-secondary mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                No videos found
              </h3>
              <p className="text-text-secondary">
                Try selecting a different category or check back later for new content.
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Home;