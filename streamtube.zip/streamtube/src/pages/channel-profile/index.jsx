import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import MainHeader from '../../components/ui/MainHeader';
import ChannelBanner from './components/ChannelBanner';
import ChannelTabs from './components/ChannelTabs';
import VideoGrid from './components/VideoGrid';
import PlaylistGrid from './components/PlaylistGrid';
import CommunityTab from './components/CommunityTab';
import AboutTab from './components/AboutTab';
import ChannelSidebar from './components/ChannelSidebar';

const ChannelProfile = () => {
  const [searchParams] = useSearchParams();
  const channelId = searchParams?.get('c') || 'default-channel';
  const [activeTab, setActiveTab] = useState('videos');
  const [isSubscribed, setIsSubscribed] = useState(false);

  // Mock user data
  const mockUser = {
    name: "Alex Johnson",
    email: "alex.johnson@example.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"
  };

  // Mock channel data
  const mockChannelData = {
    id: channelId,
    name: "TechExplorer Pro",
    handle: "techexplorerpro",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&h=400&fit=crop&crop=face",
    bannerImage: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=1200&h=400&fit=crop",
    subscriberCount: "2.4M",
    videoCount: 847,
    isVerified: true,
    description: "Exploring the latest in technology, gadgets, and innovation. Join us for in-depth reviews, tutorials, and tech news!",
    fullDescription: `Welcome to TechExplorer Pro! 🚀

We're passionate about bringing you the latest and greatest in technology. From cutting-edge smartphones and laptops to emerging tech trends and innovations, we cover it all.What you'll find on our channel:
• In-depth product reviews and comparisons
• Step-by-step tutorials and how-to guides  
• Breaking tech news and industry insights
• Unboxing videos of the newest gadgets
• Live streams and Q&A sessions

Our mission is to help you make informed decisions about technology purchases and stay ahead of the curve in our rapidly evolving digital world.

Don't forget to subscribe and hit the notification bell to never miss our latest content! 

Business inquiries: business@techexplorerpro.com

#Technology #Reviews #Tutorials #Innovation`,
    totalViews: 156789432,
    joinedDate: "2018-03-15",
    location: "San Francisco, CA",
    businessEmail: "business@techexplorerpro.com",
    categories: ["Technology", "Education", "Reviews", "Tutorials"],
    socialLinks: [
      {
        title: "Twitter",
        url: "https://twitter.com/techexplorerpro",
        icon: "Twitter"
      },
      {
        title: "Instagram", 
        url: "https://instagram.com/techexplorerpro",
        icon: "Instagram"
      },
      {
        title: "Website",
        url: "https://techexplorerpro.com",
        icon: "Globe"
      }
    ]
  };

  // Mock videos data
  const mockVideos = [
    {
      id: "video1",
      title: "iPhone 15 Pro Max Complete Review - Is It Worth the Upgrade?",
      thumbnail: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&h=225&fit=crop",
      duration: 1247,
      views: 2456789,
      publishedAt: "2024-01-15T10:30:00Z"
    },
    {
      id: "video2", 
      title: "MacBook Air M3 vs MacBook Pro M3 - Which Should You Buy?",
      thumbnail: "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400&h=225&fit=crop",
      duration: 892,
      views: 1834567,
      publishedAt: "2024-01-12T14:15:00Z"
    },
    {
      id: "video3",
      title: "Top 10 Tech Gadgets You NEED in 2024",
      thumbnail: "https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=400&h=225&fit=crop",
      duration: 1456,
      views: 3245678,
      publishedAt: "2024-01-08T09:45:00Z"
    },
    {
      id: "video4",
      title: "Samsung Galaxy S24 Ultra First Look - Camera Test & Features",
      thumbnail: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=225&fit=crop",
      duration: 1089,
      views: 1567890,
      publishedAt: "2024-01-05T16:20:00Z"
    },
    {
      id: "video5",
      title: "Building the Ultimate Gaming Setup for 2024",
      thumbnail: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400&h=225&fit=crop",
      duration: 1834,
      views: 2789456,
      publishedAt: "2024-01-02T11:30:00Z"
    },
    {
      id: "video6",
      title: "Tesla Model 3 Highland Review - Everything You Need to Know",
      thumbnail: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=400&h=225&fit=crop",
      duration: 1623,
      views: 1923456,
      publishedAt: "2023-12-28T13:45:00Z"
    }
  ];

  // Mock playlists data
  const mockPlaylists = [
    {
      id: "playlist1",
      title: "iPhone Reviews & Tutorials",
      thumbnail: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&h=225&fit=crop",
      videoCount: 24,
      privacy: "Public",
      updatedAt: "2024-01-15T10:30:00Z",
      description: "Complete collection of iPhone reviews, tutorials, and tips"
    },
    {
      id: "playlist2",
      title: "MacBook & Mac Reviews",
      thumbnail: "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400&h=225&fit=crop",
      videoCount: 18,
      privacy: "Public", 
      updatedAt: "2024-01-12T14:15:00Z",
      description: "Everything about MacBooks, iMacs, and Mac accessories"
    },
    {
      id: "playlist3",
      title: "Gaming Tech & Setups",
      thumbnail: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400&h=225&fit=crop",
      videoCount: 31,
      privacy: "Public",
      updatedAt: "2024-01-08T09:45:00Z",
      description: "Gaming laptops, desktops, peripherals, and setup guides"
    },
    {
      id: "playlist4",
      title: "Electric Vehicle Reviews",
      thumbnail: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=400&h=225&fit=crop",
      videoCount: 12,
      privacy: "Public",
      updatedAt: "2024-01-02T11:30:00Z",
      description: "Tesla, Rivian, and other EV reviews and comparisons"
    }
  ];

  // Mock community posts data
  const mockCommunityPosts = [
    {
      id: "post1",
      content: `Just finished testing the new iPhone 15 Pro Max for our upcoming review! 📱✨

The camera improvements are genuinely impressive, especially in low light conditions. The Action Button is more useful than I initially thought it would be.

What features are you most excited about? Drop your thoughts below! 👇`,
      image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=600&h=400&fit=crop",
      likes: 15420,
      comments: 892,
      createdAt: "2024-01-16T09:30:00Z"
    },
    {
      id: "post2",
      content: `Quick poll for our community! 🗳️

We're planning our next big comparison video. Which matchup would you like to see most?`,
      poll: {
        question: "Which comparison video should we make next?",
        options: [
          { text: "MacBook Air M3 vs Surface Laptop 5", percentage: 35 },
          { text: "iPhone 15 Pro vs Pixel 8 Pro", percentage: 28 },
          { text: "iPad Pro vs Surface Pro 9", percentage: 22 },
          { text: "AirPods Pro vs Sony WH-1000XM5", percentage: 15 }
        ],
        totalVotes: 8934
      },
      likes: 8934,
      comments: 456,
      createdAt: "2024-01-14T15:45:00Z"
    },
    {
      id: "post3",
      content: `Behind the scenes from yesterday's MacBook review shoot! 🎬 It's always exciting to unbox and test new tech. The M3 chip performance has been incredible so far. Full review dropping this Friday!

Thanks to everyone who suggested questions in our last community post - we made sure to address them all in the video. 🙏`,
      image: "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=600&h=400&fit=crop",
      likes: 12567,
      comments: 234,
      createdAt: "2024-01-11T18:20:00Z"
    }
  ];

  // Mock sidebar data
  const mockChannelStats = {
    totalViews: 156789432,
    subscribers: 2400000,
    videoCount: 847,
    joinedDate: "2018-03-15"
  };

  const mockFeaturedPlaylists = [
    {
      id: "featured1",
      title: "Best Tech of 2024",
      thumbnail: "https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=400&h=225&fit=crop",
      videoCount: 15
    },
    {
      id: "featured2", 
      title: "iPhone Complete Guide",
      thumbnail: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&h=225&fit=crop",
      videoCount: 24
    }
  ];

  const mockRelatedChannels = [
    {
      id: "related1",
      name: "TechReview Central",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
      subscribers: 1800000,
      isVerified: true
    },
    {
      id: "related2",
      name: "GadgetGuru",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face", 
      subscribers: 950000,
      isVerified: false
    },
    {
      id: "related3",
      name: "Innovation Hub",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
      subscribers: 2100000,
      isVerified: true
    }
  ];

  const handleSubscribe = () => {
    setIsSubscribed(!isSubscribed);
  };

  const handleNotificationToggle = () => {
    console.log('Notification preferences toggled');
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'videos':
        return <VideoGrid videos={mockVideos} />;
      case 'playlists':
        return <PlaylistGrid playlists={mockPlaylists} />;
      case 'community':
        return <CommunityTab posts={mockCommunityPosts} channelInfo={mockChannelData} />;
      case 'about':
        return <AboutTab channelInfo={mockChannelData} />;
      default:
        return <VideoGrid videos={mockVideos} />;
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} user={mockUser} />
      
      <main className="pt-14 md:pt-16">
        {/* Channel Banner */}
        <ChannelBanner
          channel={mockChannelData}
          isSubscribed={isSubscribed}
          onSubscribe={handleSubscribe}
          onNotificationToggle={handleNotificationToggle}
        />

        {/* Channel Tabs */}
        <ChannelTabs activeTab={activeTab} onTabChange={setActiveTab} />

        {/* Content Area */}
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Main Content */}
            <div className="flex-1 min-w-0">
              {renderTabContent()}
            </div>

            {/* Sidebar - Desktop Only */}
            <div className="hidden lg:block w-80 flex-shrink-0">
              <div className="sticky top-24">
                <ChannelSidebar
                  channelStats={mockChannelStats}
                  featuredPlaylists={mockFeaturedPlaylists}
                  relatedChannels={mockRelatedChannels}
                />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ChannelProfile;