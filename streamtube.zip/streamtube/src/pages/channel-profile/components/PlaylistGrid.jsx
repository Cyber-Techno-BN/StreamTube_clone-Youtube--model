import React from 'react';
import { useNavigate } from 'react-router-dom';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';

const PlaylistGrid = ({ playlists }) => {
  const navigate = useNavigate();

  const handlePlaylistClick = (playlistId) => {
    navigate(`/playlist?list=${playlistId}`);
  };

  const formatTimeAgo = (date) => {
    const now = new Date();
    const playlistDate = new Date(date);
    const diffInSeconds = Math.floor((now - playlistDate) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    if (diffInSeconds < 31536000) return `${Math.floor(diffInSeconds / 2592000)} months ago`;
    return `${Math.floor(diffInSeconds / 31536000)} years ago`;
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
        {playlists?.map((playlist) => (
          <div
            key={playlist?.id}
            className="group cursor-pointer"
            onClick={() => handlePlaylistClick(playlist?.id)}
          >
            {/* Playlist Thumbnail */}
            <div className="relative aspect-video rounded-lg overflow-hidden bg-muted mb-3">
              <Image
                src={playlist?.thumbnail}
                alt={playlist?.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
              />
              
              {/* Video Count Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-2 right-2 flex items-center space-x-1 text-white text-sm">
                <Icon name="List" size={16} />
                <span>{playlist?.videoCount} videos</span>
              </div>

              {/* Play All Button */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <div className="bg-white/90 rounded-full p-3">
                  <Icon name="Play" size={24} className="text-black ml-1" />
                </div>
              </div>
            </div>

            {/* Playlist Info */}
            <div className="space-y-1">
              <h3 className="font-medium text-foreground line-clamp-2 group-hover:text-primary transition-colors duration-200">
                {playlist?.title}
              </h3>
              <div className="flex items-center text-sm text-text-secondary space-x-1">
                <span>{playlist?.privacy}</span>
                <span>•</span>
                <span>Updated {formatTimeAgo(playlist?.updatedAt)}</span>
              </div>
              {playlist?.description && (
                <p className="text-sm text-text-secondary line-clamp-2">
                  {playlist?.description}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PlaylistGrid;