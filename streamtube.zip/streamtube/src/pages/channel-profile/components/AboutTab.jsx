import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AboutTab = ({ channelInfo }) => {
  const formatNumber = (num) => {
    if (num >= 1000000) {
      return `${(num / 1000000)?.toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000)?.toFixed(1)}K`;
    }
    return num?.toLocaleString();
  };

  const formatDate = (date) => {
    return new Date(date)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-8">
      {/* Channel Description */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-card-foreground mb-4">Description</h3>
        <div className="prose prose-sm max-w-none">
          <p className="text-card-foreground whitespace-pre-wrap leading-relaxed">
            {channelInfo?.fullDescription}
          </p>
        </div>
      </div>
      {/* Channel Statistics */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-card-foreground mb-4">Stats</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center md:text-left">
            <div className="text-2xl font-bold text-primary mb-1">
              {formatNumber(channelInfo?.subscriberCount)}
            </div>
            <div className="text-sm text-text-secondary">Subscribers</div>
          </div>
          <div className="text-center md:text-left">
            <div className="text-2xl font-bold text-primary mb-1">
              {formatNumber(channelInfo?.totalViews)}
            </div>
            <div className="text-sm text-text-secondary">Total views</div>
          </div>
          <div className="text-center md:text-left">
            <div className="text-2xl font-bold text-primary mb-1">
              {channelInfo?.videoCount}
            </div>
            <div className="text-sm text-text-secondary">Videos</div>
          </div>
        </div>
        <div className="mt-6 pt-6 border-t border-border">
          <div className="flex items-center text-sm text-text-secondary">
            <Icon name="Calendar" size={16} className="mr-2" />
            <span>Joined {formatDate(channelInfo?.joinedDate)}</span>
          </div>
        </div>
      </div>
      {/* Social Links */}
      {channelInfo?.socialLinks && channelInfo?.socialLinks?.length > 0 && (
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-card-foreground mb-4">Links</h3>
          <div className="space-y-3">
            {channelInfo?.socialLinks?.map((link, index) => (
              <a
                key={index}
                href={link?.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted transition-colors duration-200 group"
              >
                <Icon
                  name={link?.icon}
                  size={20}
                  className="text-text-secondary group-hover:text-primary transition-colors duration-200"
                />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-card-foreground group-hover:text-primary transition-colors duration-200">
                    {link?.title}
                  </div>
                  <div className="text-sm text-text-secondary truncate">
                    {link?.url}
                  </div>
                </div>
                <Icon
                  name="ExternalLink"
                  size={16}
                  className="text-text-secondary group-hover:text-primary transition-colors duration-200"
                />
              </a>
            ))}
          </div>
        </div>
      )}
      {/* Channel Details */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-card-foreground mb-4">Details</h3>
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <Icon name="MapPin" size={16} className="text-text-secondary mt-1" />
            <div>
              <div className="font-medium text-card-foreground">Location</div>
              <div className="text-sm text-text-secondary">{channelInfo?.location}</div>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <Icon name="Mail" size={16} className="text-text-secondary mt-1" />
            <div>
              <div className="font-medium text-card-foreground">Business inquiries</div>
              <div className="text-sm text-text-secondary">{channelInfo?.businessEmail}</div>
            </div>
          </div>

          {channelInfo?.categories && channelInfo?.categories?.length > 0 && (
            <div className="flex items-start space-x-3">
              <Icon name="Tag" size={16} className="text-text-secondary mt-1" />
              <div>
                <div className="font-medium text-card-foreground">Categories</div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {channelInfo?.categories?.map((category, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-muted text-sm text-text-secondary rounded-full"
                    >
                      {category}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* Report Channel */}
      <div className="flex justify-center pt-4">
        <Button variant="ghost" iconName="Flag" iconPosition="left" className="text-text-secondary">
          Report channel
        </Button>
      </div>
    </div>
  );
};

export default AboutTab;