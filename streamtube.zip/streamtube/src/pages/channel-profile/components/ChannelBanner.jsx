import React from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChannelBanner = ({ channel, isSubscribed, onSubscribe, onNotificationToggle }) => {
  return (
    <div className="relative w-full">
      {/* Banner Image */}
      <div className="relative w-full h-32 md:h-48 lg:h-64 overflow-hidden bg-muted">
        <Image
          src={channel?.bannerImage}
          alt={`${channel?.name} banner`}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
      </div>
      {/* Channel Info Overlay */}
      <div className="relative px-4 md:px-6 -mt-12 md:-mt-16">
        <div className="flex flex-col md:flex-row md:items-end md:space-x-6">
          {/* Avatar */}
          <div className="relative mb-4 md:mb-0">
            <div className="w-20 h-20 md:w-32 md:h-32 rounded-full overflow-hidden bg-background border-4 border-background shadow-lg">
              <Image
                src={channel?.avatar}
                alt={`${channel?.name} avatar`}
                className="w-full h-full object-cover"
              />
            </div>
            {channel?.isVerified && (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 md:w-8 md:h-8 bg-primary rounded-full flex items-center justify-center border-2 border-background">
                <Icon name="Check" size={12} color="white" className="md:w-4 md:h-4" />
              </div>
            )}
          </div>

          {/* Channel Details */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-4 md:mb-0">
                <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-1">
                  {channel?.name}
                </h1>
                <div className="flex flex-wrap items-center gap-2 text-sm text-text-secondary">
                  <span>@{channel?.handle}</span>
                  <span>•</span>
                  <span>{channel?.subscriberCount} subscribers</span>
                  <span>•</span>
                  <span>{channel?.videoCount} videos</span>
                </div>
                {channel?.description && (
                  <p className="text-sm text-text-secondary mt-2 line-clamp-2 md:line-clamp-1">
                    {channel?.description}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-3">
                <Button
                  variant={isSubscribed ? "outline" : "default"}
                  onClick={onSubscribe}
                  iconName={isSubscribed ? "Check" : "Plus"}
                  iconPosition="left"
                  className={isSubscribed ? "text-foreground" : "bg-primary hover:bg-primary/90"}
                >
                  {isSubscribed ? "Subscribed" : "Subscribe"}
                </Button>

                {isSubscribed && (
                  <Button
                    variant="ghost"
                    size="icon"
                    iconName="Bell"
                    onClick={onNotificationToggle}
                    className="text-text-secondary hover:text-foreground"
                  />
                )}

                <Button
                  variant="ghost"
                  size="icon"
                  iconName="Share"
                  className="text-text-secondary hover:text-foreground"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChannelBanner;