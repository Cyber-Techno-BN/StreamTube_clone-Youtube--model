import React from 'react';
import { useNavigate } from 'react-router-dom';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChannelSidebar = ({ channelStats, featuredPlaylists, relatedChannels }) => {
  const navigate = useNavigate();

  const formatNumber = (num) => {
    if (num >= 1000000) {
      return `${(num / 1000000)?.toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000)?.toFixed(1)}K`;
    }
    return num?.toLocaleString();
  };

  const handlePlaylistClick = (playlistId) => {
    navigate(`/playlist?list=${playlistId}`);
  };

  const handleChannelClick = (channelId) => {
    navigate(`/channel-profile?c=${channelId}`);
  };

  return (
    <div className="space-y-6">
      {/* Channel Statistics */}
      <div className="bg-card border border-border rounded-lg p-4">
        <h3 className="font-semibold text-card-foreground mb-4">Statistics</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Total views</span>
            <span className="font-medium text-card-foreground">
              {formatNumber(channelStats?.totalViews)}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Subscribers</span>
            <span className="font-medium text-card-foreground">
              {formatNumber(channelStats?.subscribers)}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Videos</span>
            <span className="font-medium text-card-foreground">
              {channelStats?.videoCount}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Joined</span>
            <span className="font-medium text-card-foreground">
              {new Date(channelStats.joinedDate)?.getFullYear()}
            </span>
          </div>
        </div>
      </div>
      {/* Featured Playlists */}
      {featuredPlaylists && featuredPlaylists?.length > 0 && (
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="font-semibold text-card-foreground mb-4">Featured Playlists</h3>
          <div className="space-y-3">
            {featuredPlaylists?.map((playlist) => (
              <div
                key={playlist?.id}
                className="group cursor-pointer"
                onClick={() => handlePlaylistClick(playlist?.id)}
              >
                <div className="flex space-x-3">
                  <div className="w-16 h-12 rounded overflow-hidden bg-muted flex-shrink-0">
                    <Image
                      src={playlist?.thumbnail}
                      alt={playlist?.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium text-card-foreground line-clamp-2 group-hover:text-primary transition-colors duration-200">
                      {playlist?.title}
                    </h4>
                    <p className="text-xs text-text-secondary mt-1">
                      {playlist?.videoCount} videos
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <Button
            variant="ghost"
            className="w-full mt-4 text-sm"
            iconName="ChevronRight"
            iconPosition="right"
          >
            View all playlists
          </Button>
        </div>
      )}
      {/* Related Channels */}
      {relatedChannels && relatedChannels?.length > 0 && (
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="font-semibold text-card-foreground mb-4">Related Channels</h3>
          <div className="space-y-4">
            {relatedChannels?.map((channel) => (
              <div
                key={channel?.id}
                className="group cursor-pointer"
                onClick={() => handleChannelClick(channel?.id)}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full overflow-hidden bg-muted flex-shrink-0">
                    <Image
                      src={channel?.avatar}
                      alt={channel?.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-1">
                      <h4 className="text-sm font-medium text-card-foreground group-hover:text-primary transition-colors duration-200 truncate">
                        {channel?.name}
                      </h4>
                      {channel?.isVerified && (
                        <Icon name="Check" size={12} className="text-primary flex-shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-text-secondary">
                      {formatNumber(channel?.subscribers)} subscribers
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ChannelSidebar;