import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const VideoGrid = ({ videos }) => {
  const navigate = useNavigate();
  const [sortBy, setSortBy] = useState('newest');
  const [filterBy, setFilterBy] = useState('all');

  const sortOptions = [
    { value: 'newest', label: 'Newest first' },
    { value: 'oldest', label: 'Oldest first' },
    { value: 'popular', label: 'Most popular' },
    { value: 'views', label: 'Most viewed' }
  ];

  const filterOptions = [
    { value: 'all', label: 'All videos' },
    { value: 'uploads', label: 'Uploads' },
    { value: 'shorts', label: 'Shorts' },
    { value: 'live', label: 'Live streams' }
  ];

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${secs?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const formatViews = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000)?.toFixed(1)}M views`;
    } else if (views >= 1000) {
      return `${(views / 1000)?.toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const formatTimeAgo = (date) => {
    const now = new Date();
    const videoDate = new Date(date);
    const diffInSeconds = Math.floor((now - videoDate) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    if (diffInSeconds < 31536000) return `${Math.floor(diffInSeconds / 2592000)} months ago`;
    return `${Math.floor(diffInSeconds / 31536000)} years ago`;
  };

  const handleVideoClick = (videoId) => {
    navigate(`/video-player?v=${videoId}`);
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Select
          options={sortOptions}
          value={sortBy}
          onChange={setSortBy}
          placeholder="Sort by"
          className="w-full sm:w-48"
        />
        <Select
          options={filterOptions}
          value={filterBy}
          onChange={setFilterBy}
          placeholder="Filter by"
          className="w-full sm:w-48"
        />
      </div>
      {/* Video Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
        {videos?.map((video) => (
          <div
            key={video?.id}
            className="group cursor-pointer"
            onClick={() => handleVideoClick(video?.id)}
          >
            {/* Thumbnail */}
            <div className="relative aspect-video rounded-lg overflow-hidden bg-muted mb-3">
              <Image
                src={video?.thumbnail}
                alt={video?.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
              />
              
              {/* Duration */}
              <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded">
                {formatDuration(video?.duration)}
              </div>

              {/* Play overlay */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-200 flex items-center justify-center">
                <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <Icon name="Play" size={20} className="text-black ml-1" />
                </div>
              </div>
            </div>

            {/* Video Info */}
            <div className="space-y-1">
              <h3 className="font-medium text-foreground line-clamp-2 group-hover:text-primary transition-colors duration-200">
                {video?.title}
              </h3>
              <div className="flex items-center text-sm text-text-secondary space-x-1">
                <span>{formatViews(video?.views)}</span>
                <span>•</span>
                <span>{formatTimeAgo(video?.publishedAt)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Load More */}
      {videos?.length > 0 && (
        <div className="flex justify-center pt-8">
          <Button variant="outline" iconName="ChevronDown" iconPosition="right">
            Load More Videos
          </Button>
        </div>
      )}
    </div>
  );
};

export default VideoGrid;