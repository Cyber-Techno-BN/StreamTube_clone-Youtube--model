import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';


const CommunityTab = ({ posts, channelInfo }) => {
  const [likedPosts, setLikedPosts] = useState(new Set());

  const handleLike = (postId) => {
    setLikedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet?.has(postId)) {
        newSet?.delete(postId);
      } else {
        newSet?.add(postId);
      }
      return newSet;
    });
  };

  const formatTimeAgo = (date) => {
    const now = new Date();
    const postDate = new Date(date);
    const diffInSeconds = Math.floor((now - postDate) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    if (diffInSeconds < 31536000) return `${Math.floor(diffInSeconds / 2592000)} months ago`;
    return `${Math.floor(diffInSeconds / 31536000)} years ago`;
  };

  const formatNumber = (num) => {
    if (num >= 1000000) {
      return `${(num / 1000000)?.toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000)?.toFixed(1)}K`;
    }
    return num?.toString();
  };

  return (
    <div className="space-y-6">
      {posts?.map((post) => (
        <div key={post?.id} className="bg-card border border-border rounded-lg p-4 md:p-6">
          {/* Post Header */}
          <div className="flex items-start space-x-3 mb-4">
            <div className="w-10 h-10 rounded-full overflow-hidden bg-muted flex-shrink-0">
              <Image
                src={channelInfo?.avatar}
                alt={channelInfo?.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2">
                <h4 className="font-medium text-card-foreground">{channelInfo?.name}</h4>
                {channelInfo?.isVerified && (
                  <Icon name="Check" size={16} className="text-primary" />
                )}
              </div>
              <p className="text-sm text-text-secondary">{formatTimeAgo(post?.createdAt)}</p>
            </div>
          </div>

          {/* Post Content */}
          <div className="mb-4">
            <p className="text-card-foreground whitespace-pre-wrap">{post?.content}</p>
            
            {/* Post Image */}
            {post?.image && (
              <div className="mt-4 rounded-lg overflow-hidden">
                <Image
                  src={post?.image}
                  alt="Post image"
                  className="w-full max-h-96 object-cover"
                />
              </div>
            )}

            {/* Poll */}
            {post?.poll && (
              <div className="mt-4 space-y-3">
                <h5 className="font-medium text-card-foreground">{post?.poll?.question}</h5>
                {post?.poll?.options?.map((option, index) => (
                  <div key={index} className="relative">
                    <button className="w-full text-left p-3 border border-border rounded-lg hover:bg-muted transition-colors duration-200">
                      <div className="flex items-center justify-between">
                        <span className="text-card-foreground">{option?.text}</span>
                        <span className="text-sm text-text-secondary">{option?.percentage}%</span>
                      </div>
                      <div className="mt-2 w-full bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all duration-300"
                          style={{ width: `${option?.percentage}%` }}
                        />
                      </div>
                    </button>
                  </div>
                ))}
                <p className="text-sm text-text-secondary">{post?.poll?.totalVotes} votes</p>
              </div>
            )}
          </div>

          {/* Post Actions */}
          <div className="flex items-center space-x-6 pt-2 border-t border-border">
            <button
              onClick={() => handleLike(post?.id)}
              className={`flex items-center space-x-2 text-sm transition-colors duration-200 ${
                likedPosts?.has(post?.id)
                  ? 'text-primary' :'text-text-secondary hover:text-foreground'
              }`}
            >
              <Icon
                name={likedPosts?.has(post?.id) ? "Heart" : "Heart"}
                size={18}
                className={likedPosts?.has(post?.id) ? "fill-current" : ""}
              />
              <span>{formatNumber(post?.likes + (likedPosts?.has(post?.id) ? 1 : 0))}</span>
            </button>

            <button className="flex items-center space-x-2 text-sm text-text-secondary hover:text-foreground transition-colors duration-200">
              <Icon name="MessageCircle" size={18} />
              <span>{formatNumber(post?.comments)}</span>
            </button>

            <button className="flex items-center space-x-2 text-sm text-text-secondary hover:text-foreground transition-colors duration-200">
              <Icon name="Share" size={18} />
              <span>Share</span>
            </button>
          </div>
        </div>
      ))}
      {posts?.length === 0 && (
        <div className="text-center py-12">
          <Icon name="MessageSquare" size={48} className="text-text-secondary mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No community posts yet</h3>
          <p className="text-text-secondary">This channel hasn't posted anything to their community tab.</p>
        </div>
      )}
    </div>
  );
};

export default CommunityTab;