import React, { useState } from 'react';
import MainHeader from '../../components/ui/MainHeader';
import UploadZone from './components/UploadZone';
import VideoMetadataForm from './components/VideoMetadataForm';
import VideoPreview from './components/VideoPreview';
import VideoLibrary from './components/VideoLibrary';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const VideoUploadManagement = () => {
  const [activeTab, setActiveTab] = useState('upload');
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [videoMetadata, setVideoMetadata] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [editingVideo, setEditingVideo] = useState(null);

  // Mock user data
  const mockUser = {
    name: "John Creator",
    email: "john@example.com",
    avatar: "https://images.pexels.com/photos/3785077/pexels-photo-3785077.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
  };

  const tabs = [
    { id: 'upload', label: 'Upload', icon: 'Upload' },
    { id: 'library', label: 'Library', icon: 'Video' },
    { id: 'analytics', label: 'Analytics', icon: 'BarChart3' }
  ];

  const handleFileSelect = (file) => {
    setSelectedVideo(file);
    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          return 100;
        }
        return prev + 10;
      });
    }, 500);
  };

  const handleMetadataSave = (metadata) => {
    setVideoMetadata(metadata);
    console.log('Video published with metadata:', metadata);
    // Reset form after successful upload
    setSelectedVideo(null);
    setVideoMetadata(null);
    setActiveTab('library');
  };

  const handleMetadataCancel = () => {
    setSelectedVideo(null);
    setVideoMetadata(null);
    setUploadProgress(0);
  };

  const handleEditVideo = (video) => {
    setEditingVideo(video);
    setActiveTab('upload');
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'upload':
        return (
          <div className="space-y-6">
            {!selectedVideo && !editingVideo ? (
              <UploadZone
                onFileSelect={handleFileSelect}
                isUploading={isUploading}
                uploadProgress={uploadProgress}
              />
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column - Form */}
                <div className="space-y-6">
                  <VideoMetadataForm
                    videoFile={selectedVideo || editingVideo}
                    onSave={handleMetadataSave}
                    onCancel={handleMetadataCancel}
                  />
                </div>
                
                {/* Right Column - Preview */}
                <div className="space-y-6">
                  <VideoPreview
                    videoFile={selectedVideo || editingVideo}
                    metadata={videoMetadata}
                  />
                </div>
              </div>
            )}
          </div>
        );
      
      case 'library':
        return <VideoLibrary onEditVideo={handleEditVideo} />;
      
      case 'analytics':
        return <AnalyticsDashboard />;
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} user={mockUser} />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                  Creator Studio
                </h1>
                <p className="text-text-secondary mt-1">
                  Upload, manage, and analyze your video content
                </p>
              </div>
              
              {/* Quick Actions */}
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  iconName="HelpCircle"
                  iconPosition="left"
                  size="sm"
                >
                  Help
                </Button>
                <Button
                  variant="outline"
                  iconName="Settings"
                  iconPosition="left"
                  size="sm"
                >
                  Settings
                </Button>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="mb-8">
            <div className="border-b border-border">
              <nav className="flex space-x-8 overflow-x-auto">
                {tabs?.map((tab) => (
                  <button
                    key={tab?.id}
                    onClick={() => {
                      setActiveTab(tab?.id);
                      if (tab?.id !== 'upload') {
                        setEditingVideo(null);
                      }
                    }}
                    className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ${
                      activeTab === tab?.id
                        ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-foreground hover:border-border'
                    }`}
                  >
                    <Icon name={tab?.icon} size={18} />
                    <span>{tab?.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          <div className="min-h-[600px]">
            {renderTabContent()}
          </div>

          {/* Upload Progress Indicator */}
          {isUploading && (
            <div className="fixed bottom-4 right-4 bg-card border border-border rounded-lg p-4 shadow-elevated max-w-sm">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <Icon name="Upload" size={20} className="text-primary animate-pulse" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Uploading video...</p>
                  <div className="w-full bg-muted rounded-full h-1.5 mt-1">
                    <div
                      className="bg-primary h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-text-secondary mt-1">{uploadProgress}% complete</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoUploadManagement;