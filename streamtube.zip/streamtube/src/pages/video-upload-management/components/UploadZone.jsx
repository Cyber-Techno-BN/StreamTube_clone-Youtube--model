import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const UploadZone = ({ onFileSelect, isUploading, uploadProgress }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef(null);

  const handleDragOver = (e) => {
    e?.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e?.dataTransfer?.files);
    const videoFiles = files?.filter(file => file?.type?.startsWith('video/'));
    if (videoFiles?.length > 0) {
      onFileSelect(videoFiles?.[0]);
    }
  };

  const handleFileSelect = (e) => {
    const file = e?.target?.files?.[0];
    if (file && file?.type?.startsWith('video/')) {
      onFileSelect(file);
    }
  };

  const handleBrowseClick = () => {
    fileInputRef?.current?.click();
  };

  const supportedFormats = ['MP4', 'MOV', 'AVI', 'WMV', 'FLV', 'WebM'];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div
        className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
          isDragOver
            ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
        } ${isUploading ? 'pointer-events-none opacity-50' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          onChange={handleFileSelect}
          className="hidden"
          disabled={isUploading}
        />

        {isUploading ? (
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
              <Icon name="Upload" size={32} className="text-primary animate-pulse" />
            </div>
            <div className="space-y-2">
              <p className="text-lg font-medium text-foreground">Uploading video...</p>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
              <p className="text-sm text-text-secondary">{uploadProgress}% complete</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
              <Icon name="Upload" size={32} className="text-text-secondary" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-medium text-foreground">
                Drag and drop video files to upload
              </h3>
              <p className="text-text-secondary">
                Your videos will be private until you publish them.
              </p>
            </div>
            <Button
              variant="default"
              onClick={handleBrowseClick}
              iconName="FolderOpen"
              iconPosition="left"
              className="mx-auto"
            >
              SELECT FILES
            </Button>
          </div>
        )}
      </div>
      <div className="mt-4 text-center">
        <p className="text-sm text-text-secondary mb-2">Supported formats:</p>
        <div className="flex flex-wrap justify-center gap-2">
          {supportedFormats?.map((format) => (
            <span
              key={format}
              className="px-2 py-1 bg-muted text-text-secondary text-xs rounded"
            >
              {format}
            </span>
          ))}
        </div>
        <p className="text-xs text-text-secondary mt-2">
          Maximum file size: 2GB • Maximum duration: 12 hours
        </p>
      </div>
    </div>
  );
};

export default UploadZone;