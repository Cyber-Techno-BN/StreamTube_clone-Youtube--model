import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const AnalyticsDashboard = () => {
  const [timeRange, setTimeRange] = useState('7days');

  const timeRangeOptions = [
    { value: '7days', label: 'Last 7 days' },
    { value: '30days', label: 'Last 30 days' },
    { value: '90days', label: 'Last 90 days' },
    { value: '1year', label: 'Last year' }
  ];

  const viewsData = [
    { date: 'Aug 14', views: 1250, watchTime: 45 },
    { date: 'Aug 15', views: 1890, watchTime: 67 },
    { date: 'Aug 16', views: 2340, watchTime: 89 },
    { date: 'Aug 17', views: 1750, watchTime: 62 },
    { date: 'Aug 18', views: 2100, watchTime: 78 },
    { date: 'Aug 19', views: 2850, watchTime: 95 },
    { date: 'Aug 20', views: 3200, watchTime: 112 }
  ];

  const topVideosData = [
    { title: 'React Tutorial', views: 15420, watchTime: '2.5h' },
    { title: 'CSS Grid Guide', views: 8750, watchTime: '1.8h' },
    { title: 'MongoDB Patterns', views: 12300, watchTime: '3.2h' },
    { title: 'JavaScript ES6', views: 6800, watchTime: '1.4h' }
  ];

  const audienceData = [
    { name: '18-24', value: 25, color: '#FF4444' },
    { name: '25-34', value: 35, color: '#2196F3' },
    { name: '35-44', value: 20, color: '#00BCD4' },
    { name: '45-54', value: 15, color: '#4CAF50' },
    { name: '55+', value: 5, color: '#FF9800' }
  ];

  const trafficSources = [
    { source: 'YouTube Search', percentage: 45, color: '#FF4444' },
    { source: 'Suggested Videos', percentage: 30, color: '#2196F3' },
    { source: 'External', percentage: 15, color: '#00BCD4' },
    { source: 'Direct', percentage: 10, color: '#4CAF50' }
  ];

  const stats = [
    {
      label: 'Total Views',
      value: '47.2K',
      change: '+12.5%',
      trend: 'up',
      icon: 'Eye'
    },
    {
      label: 'Watch Time',
      value: '1,234h',
      change: '+8.3%',
      trend: 'up',
      icon: 'Clock'
    },
    {
      label: 'Subscribers',
      value: '2.8K',
      change: '+15.2%',
      trend: 'up',
      icon: 'Users'
    },
    {
      label: 'Revenue',
      value: '$892',
      change: '-2.1%',
      trend: 'down',
      icon: 'DollarSign'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Analytics Dashboard</h2>
          <p className="text-text-secondary text-sm">
            Track your channel performance and audience insights
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Select
            options={timeRangeOptions}
            value={timeRange}
            onChange={setTimeRange}
            className="w-40"
          />
          <Button
            variant="outline"
            iconName="Download"
            iconPosition="left"
            size="sm"
          >
            Export
          </Button>
        </div>
      </div>
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats?.map((stat, index) => (
          <div key={index} className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Icon name={stat?.icon} size={20} className="text-primary" />
              </div>
              <div className={`flex items-center space-x-1 text-sm ${
                stat?.trend === 'up' ? 'text-success' : 'text-error'
              }`}>
                <Icon 
                  name={stat?.trend === 'up' ? 'TrendingUp' : 'TrendingDown'} 
                  size={14} 
                />
                <span>{stat?.change}</span>
              </div>
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stat?.value}</p>
              <p className="text-text-secondary text-sm">{stat?.label}</p>
            </div>
          </div>
        ))}
      </div>
      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Views Chart */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground">Views Over Time</h3>
            <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={viewsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis 
                  dataKey="date" 
                  stroke="var(--color-text-secondary)"
                  fontSize={12}
                />
                <YAxis 
                  stroke="var(--color-text-secondary)"
                  fontSize={12}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'var(--color-popover)',
                    border: '1px solid var(--color-border)',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="views" 
                  stroke="var(--color-primary)" 
                  strokeWidth={2}
                  dot={{ fill: 'var(--color-primary)', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Watch Time Chart */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground">Watch Time (Hours)</h3>
            <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={viewsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis 
                  dataKey="date" 
                  stroke="var(--color-text-secondary)"
                  fontSize={12}
                />
                <YAxis 
                  stroke="var(--color-text-secondary)"
                  fontSize={12}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'var(--color-popover)',
                    border: '1px solid var(--color-border)',
                    borderRadius: '8px'
                  }}
                />
                <Bar 
                  dataKey="watchTime" 
                  fill="var(--color-secondary)"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Videos */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground">Top Performing Videos</h3>
            <Button variant="ghost" size="sm" iconName="ExternalLink" />
          </div>
          <div className="space-y-4">
            {topVideosData?.map((video, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {video?.title}
                  </p>
                  <div className="flex items-center space-x-4 text-xs text-text-secondary">
                    <span>{video?.views?.toLocaleString()} views</span>
                    <span>{video?.watchTime} watch time</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-xs font-medium text-primary">
                    #{index + 1}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Audience Demographics */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground">Audience Age</h3>
            <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={audienceData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {audienceData?.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry?.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {audienceData?.map((item, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item?.color }}
                ></div>
                <span className="text-xs text-text-secondary">
                  {item?.name}: {item?.value}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Traffic Sources */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground">Traffic Sources</h3>
            <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
          </div>
          <div className="space-y-4">
            {trafficSources?.map((source, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground">{source?.source}</span>
                  <span className="text-sm font-medium text-foreground">
                    {source?.percentage}%
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="h-2 rounded-full transition-all duration-300"
                    style={{ 
                      width: `${source?.percentage}%`,
                      backgroundColor: source?.color
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;