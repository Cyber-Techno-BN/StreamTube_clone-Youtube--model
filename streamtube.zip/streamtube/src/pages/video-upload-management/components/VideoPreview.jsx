import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';


const VideoPreview = ({ videoFile, metadata }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [videoUrl, setVideoUrl] = useState(null);

  React.useEffect(() => {
    if (videoFile) {
      const url = URL.createObjectURL(videoFile);
      setVideoUrl(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [videoFile]);

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i))?.toFixed(2)) + ' ' + sizes?.[i];
  };

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${secs?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${secs?.toString()?.padStart(2, '0')}`;
  };

  if (!videoFile) {
    return (
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="text-center py-12">
          <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center mb-4">
            <Icon name="Video" size={32} className="text-text-secondary" />
          </div>
          <h3 className="text-lg font-medium text-foreground mb-2">No video selected</h3>
          <p className="text-text-secondary">Upload a video to see the preview</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      {/* Video Preview */}
      <div className="relative aspect-video bg-black">
        {videoUrl ? (
          <video
            src={videoUrl}
            className="w-full h-full object-contain"
            controls
            poster={metadata?.thumbnail && typeof metadata?.thumbnail === 'string' ? metadata?.thumbnail : undefined}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="text-center">
              <Icon name="Video" size={48} className="text-white/50 mx-auto mb-2" />
              <p className="text-white/70">Loading video...</p>
            </div>
          </div>
        )}
      </div>
      {/* Video Info */}
      <div className="p-6 space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-2">
            {metadata?.title || videoFile?.name}
          </h3>
          {metadata?.description && (
            <p className="text-text-secondary text-sm line-clamp-3">
              {metadata?.description}
            </p>
          )}
        </div>

        {/* File Details */}
        <div className="grid grid-cols-2 gap-4 py-4 border-t border-border">
          <div>
            <p className="text-xs text-text-secondary uppercase tracking-wide mb-1">File Size</p>
            <p className="text-sm font-medium text-foreground">{formatFileSize(videoFile?.size)}</p>
          </div>
          <div>
            <p className="text-xs text-text-secondary uppercase tracking-wide mb-1">Format</p>
            <p className="text-sm font-medium text-foreground">{videoFile?.type?.split('/')?.[1]?.toUpperCase()}</p>
          </div>
        </div>

        {/* Processing Status */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-foreground">Processing Status</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-warning rounded-full animate-pulse"></div>
              <span className="text-xs text-text-secondary">Processing</span>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-text-secondary">Upload</span>
              <Icon name="Check" size={14} className="text-success" />
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-text-secondary">Video processing</span>
              <div className="w-4 h-4 border-2 border-warning border-t-transparent rounded-full animate-spin"></div>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-text-secondary">HD processing</span>
              <Icon name="Clock" size={14} className="text-text-secondary" />
            </div>
          </div>
        </div>

        {/* Quality Options */}
        <div className="space-y-2">
          <p className="text-sm font-medium text-foreground">Available Qualities</p>
          <div className="flex flex-wrap gap-2">
            {['360p', '720p', '1080p']?.map((quality) => (
              <span
                key={quality}
                className="px-2 py-1 bg-muted text-text-secondary text-xs rounded flex items-center space-x-1"
              >
                <Icon name="Video" size={12} />
                <span>{quality}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Thumbnail Preview */}
        {metadata?.thumbnail && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-foreground">Selected Thumbnail</p>
            <div className="w-32 h-20 rounded overflow-hidden border border-border">
              <Image
                src={typeof metadata?.thumbnail === 'string' ? metadata?.thumbnail : URL.createObjectURL(metadata?.thumbnail)}
                alt="Selected thumbnail"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        )}

        {/* Tags */}
        {metadata?.tags && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-foreground">Tags</p>
            <div className="flex flex-wrap gap-1">
              {metadata?.tags?.split(',')?.map((tag, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-accent/10 text-accent text-xs rounded"
                >
                  #{tag?.trim()}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Privacy Setting */}
        {metadata?.privacy && (
          <div className="flex items-center justify-between py-2 border-t border-border">
            <span className="text-sm text-text-secondary">Visibility</span>
            <div className="flex items-center space-x-2">
              <Icon 
                name={metadata?.privacy === 'public' ? 'Globe' : metadata?.privacy === 'unlisted' ? 'Link' : 'Lock'} 
                size={14} 
                className="text-text-secondary" 
              />
              <span className="text-sm font-medium text-foreground capitalize">
                {metadata?.privacy}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoPreview;