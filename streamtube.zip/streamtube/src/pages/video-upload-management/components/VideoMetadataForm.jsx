import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const VideoMetadataForm = ({ videoFile, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    tags: '',
    privacy: 'private',
    thumbnail: null,
    allowComments: true,
    ageRestricted: false,
    monetization: false
  });

  const [thumbnailPreview, setThumbnailPreview] = useState(null);
  const [autoThumbnails] = useState([
    'https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
    'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
    'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop'
  ]);

  const categoryOptions = [
    { value: 'entertainment', label: 'Entertainment' },
    { value: 'education', label: 'Education' },
    { value: 'gaming', label: 'Gaming' },
    { value: 'music', label: 'Music' },
    { value: 'sports', label: 'Sports' },
    { value: 'technology', label: 'Technology' },
    { value: 'travel', label: 'Travel & Events' },
    { value: 'lifestyle', label: 'Lifestyle' },
    { value: 'news', label: 'News & Politics' },
    { value: 'comedy', label: 'Comedy' }
  ];

  const privacyOptions = [
    { value: 'private', label: 'Private', description: 'Only you can see this video' },
    { value: 'unlisted', label: 'Unlisted', description: 'Anyone with the link can see this video' },
    { value: 'public', label: 'Public', description: 'Everyone can see this video' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleThumbnailUpload = (e) => {
    const file = e?.target?.files?.[0];
    if (file && file?.type?.startsWith('image/')) {
      setFormData(prev => ({ ...prev, thumbnail: file }));
      const reader = new FileReader();
      reader.onload = (e) => setThumbnailPreview(e?.target?.result);
      reader?.readAsDataURL(file);
    }
  };

  const handleAutoThumbnailSelect = (thumbnail) => {
    setFormData(prev => ({ ...prev, thumbnail: thumbnail }));
    setThumbnailPreview(thumbnail);
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    onSave(formData);
  };

  const suggestedTags = ['tutorial', 'howto', 'review', 'unboxing', 'vlog', 'gaming', 'music', 'comedy'];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Video Details</h2>
        <div className="flex items-center space-x-2">
          <Icon name="Save" size={16} className="text-text-secondary" />
          <span className="text-sm text-text-secondary">Auto-saved</span>
        </div>
      </div>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Title */}
        <Input
          label="Title"
          type="text"
          placeholder="Add a title that describes your video"
          value={formData?.title}
          onChange={(e) => handleInputChange('title', e?.target?.value)}
          required
          maxLength={100}
          description={`${formData?.title?.length}/100 characters`}
        />

        {/* Description */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-foreground">
            Description
          </label>
          <textarea
            className="w-full h-32 px-3 py-2 bg-input border border-border rounded-lg text-sm text-foreground placeholder:text-text-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
            placeholder="Tell viewers about your video"
            value={formData?.description}
            onChange={(e) => handleInputChange('description', e?.target?.value)}
            maxLength={5000}
          />
          <p className="text-xs text-text-secondary">{formData?.description?.length}/5000 characters</p>
        </div>

        {/* Thumbnail Selection */}
        <div className="space-y-4">
          <label className="block text-sm font-medium text-foreground">
            Thumbnail
          </label>
          
          {/* Auto-generated thumbnails */}
          <div className="grid grid-cols-3 gap-4 mb-4">
            {autoThumbnails?.map((thumbnail, index) => (
              <button
                key={index}
                type="button"
                onClick={() => handleAutoThumbnailSelect(thumbnail)}
                className={`relative aspect-video rounded-lg overflow-hidden border-2 transition-all duration-200 ${
                  formData?.thumbnail === thumbnail
                    ? 'border-primary ring-2 ring-primary/20' :'border-border hover:border-primary/50'
                }`}
              >
                <Image
                  src={thumbnail}
                  alt={`Auto-generated thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
                {formData?.thumbnail === thumbnail && (
                  <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                    <Icon name="Check" size={24} className="text-primary" />
                  </div>
                )}
              </button>
            ))}
          </div>

          {/* Custom thumbnail upload */}
          <div className="flex items-center space-x-4">
            <Button
              type="button"
              variant="outline"
              iconName="Upload"
              iconPosition="left"
              onClick={() => document.getElementById('thumbnail-upload')?.click()}
            >
              Upload custom
            </Button>
            <input
              id="thumbnail-upload"
              type="file"
              accept="image/*"
              onChange={handleThumbnailUpload}
              className="hidden"
            />
            {thumbnailPreview && typeof thumbnailPreview === 'string' && thumbnailPreview?.startsWith('data:') && (
              <div className="w-20 h-12 rounded overflow-hidden border border-border">
                <Image
                  src={thumbnailPreview}
                  alt="Custom thumbnail preview"
                  className="w-full h-full object-cover"
                />
              </div>
            )}
          </div>
        </div>

        {/* Category and Tags */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            label="Category"
            options={categoryOptions}
            value={formData?.category}
            onChange={(value) => handleInputChange('category', value)}
            placeholder="Select a category"
            required
          />
          
          <Input
            label="Tags"
            type="text"
            placeholder="Add tags separated by commas"
            value={formData?.tags}
            onChange={(e) => handleInputChange('tags', e?.target?.value)}
            description="Help people find your video"
          />
        </div>

        {/* Suggested Tags */}
        <div className="space-y-2">
          <p className="text-sm font-medium text-foreground">Suggested tags:</p>
          <div className="flex flex-wrap gap-2">
            {suggestedTags?.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => {
                  const currentTags = formData?.tags?.split(',')?.map(t => t?.trim())?.filter(t => t);
                  if (!currentTags?.includes(tag)) {
                    const newTags = [...currentTags, tag]?.join(', ');
                    handleInputChange('tags', newTags);
                  }
                }}
                className="px-3 py-1 bg-muted text-text-secondary text-sm rounded-full hover:bg-primary hover:text-primary-foreground transition-colors duration-200"
              >
                #{tag}
              </button>
            ))}
          </div>
        </div>

        {/* Privacy Settings */}
        <Select
          label="Visibility"
          options={privacyOptions}
          value={formData?.privacy}
          onChange={(value) => handleInputChange('privacy', value)}
          required
        />

        {/* Advanced Options */}
        <div className="space-y-4 p-4 bg-muted/30 rounded-lg">
          <h3 className="text-sm font-medium text-foreground">Advanced Options</h3>
          
          <Checkbox
            label="Allow comments and ratings"
            checked={formData?.allowComments}
            onChange={(e) => handleInputChange('allowComments', e?.target?.checked)}
          />
          
          <Checkbox
            label="Age-restricted (18+ only)"
            description="Restrict this content to viewers over 18"
            checked={formData?.ageRestricted}
            onChange={(e) => handleInputChange('ageRestricted', e?.target?.checked)}
          />
          
          <Checkbox
            label="Enable monetization"
            description="Allow ads to be shown on this video"
            checked={formData?.monetization}
            onChange={(e) => handleInputChange('monetization', e?.target?.checked)}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-border">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            className="sm:w-auto"
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="secondary"
            iconName="Save"
            iconPosition="left"
            className="sm:w-auto"
          >
            Save Draft
          </Button>
          <Button
            type="submit"
            variant="default"
            iconName="Upload"
            iconPosition="left"
            className="sm:w-auto"
          >
            Publish Video
          </Button>
        </div>
      </form>
    </div>
  );
};

export default VideoMetadataForm;