import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const VideoLibrary = ({ onEditVideo }) => {
  const [selectedVideos, setSelectedVideos] = useState([]);
  const [filterStatus, setFilterStatus] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [searchQuery, setSearchQuery] = useState('');

  const mockVideos = [
    {
      id: 1,
      title: "Complete React Tutorial for Beginners 2024",
      thumbnail: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      duration: "45:32",
      status: "published",
      views: 15420,
      likes: 892,
      comments: 156,
      uploadDate: "2024-08-18",
      privacy: "public"
    },
    {
      id: 2,
      title: "JavaScript ES6 Features Explained",
      thumbnail: "https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      duration: "28:15",
      status: "processing",
      views: 0,
      likes: 0,
      comments: 0,
      uploadDate: "2024-08-20",
      privacy: "public"
    },
    {
      id: 3,
      title: "Building a REST API with Node.js",
      thumbnail: "https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      duration: "1:12:45",
      status: "draft",
      views: 0,
      likes: 0,
      comments: 0,
      uploadDate: "2024-08-19",
      privacy: "private"
    },
    {
      id: 4,
      title: "CSS Grid Layout Masterclass",
      thumbnail: "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      duration: "35:20",
      status: "published",
      views: 8750,
      likes: 445,
      comments: 89,
      uploadDate: "2024-08-15",
      privacy: "public"
    },
    {
      id: 5,
      title: "MongoDB Database Design Patterns",
      thumbnail: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      duration: "52:18",
      status: "published",
      views: 12300,
      likes: 678,
      comments: 234,
      uploadDate: "2024-08-12",
      privacy: "unlisted"
    }
  ];

  const statusOptions = [
    { value: 'all', label: 'All Videos' },
    { value: 'published', label: 'Published' },
    { value: 'processing', label: 'Processing' },
    { value: 'draft', label: 'Drafts' }
  ];

  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'views', label: 'Most Views' },
    { value: 'likes', label: 'Most Likes' }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'published': return 'CheckCircle';
      case 'processing': return 'Clock';
      case 'draft': return 'Edit';
      default: return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'published': return 'text-success';
      case 'processing': return 'text-warning';
      case 'draft': return 'text-text-secondary';
      default: return 'text-text-secondary';
    }
  };

  const getPrivacyIcon = (privacy) => {
    switch (privacy) {
      case 'public': return 'Globe';
      case 'unlisted': return 'Link';
      case 'private': return 'Lock';
      default: return 'Globe';
    }
  };

  const formatNumber = (num) => {
    if (num >= 1000000) return (num / 1000000)?.toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000)?.toFixed(1) + 'K';
    return num?.toString();
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  const filteredVideos = mockVideos?.filter(video => {
    const matchesStatus = filterStatus === 'all' || video?.status === filterStatus;
    const matchesSearch = video?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleVideoSelect = (videoId) => {
    setSelectedVideos(prev => 
      prev?.includes(videoId) 
        ? prev?.filter(id => id !== videoId)
        : [...prev, videoId]
    );
  };

  const handleSelectAll = () => {
    if (selectedVideos?.length === filteredVideos?.length) {
      setSelectedVideos([]);
    } else {
      setSelectedVideos(filteredVideos?.map(video => video?.id));
    }
  };

  const handleBulkAction = (action) => {
    console.log(`Performing ${action} on videos:`, selectedVideos);
    setSelectedVideos([]);
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Video Library</h2>
            <p className="text-text-secondary text-sm">
              Manage your uploaded videos ({filteredVideos?.length} videos)
            </p>
          </div>
          
          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="w-full sm:w-64">
              <Input
                type="search"
                placeholder="Search videos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e?.target?.value)}
              />
            </div>
            <Select
              options={statusOptions}
              value={filterStatus}
              onChange={setFilterStatus}
              className="w-full sm:w-auto"
            />
            <Select
              options={sortOptions}
              value={sortBy}
              onChange={setSortBy}
              className="w-full sm:w-auto"
            />
          </div>
        </div>

        {/* Bulk Actions */}
        {selectedVideos?.length > 0 && (
          <div className="mt-4 p-3 bg-muted/30 rounded-lg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center space-x-3">
              <Checkbox
                checked={selectedVideos?.length === filteredVideos?.length}
                onChange={handleSelectAll}
              />
              <span className="text-sm text-foreground">
                {selectedVideos?.length} video{selectedVideos?.length !== 1 ? 's' : ''} selected
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                iconName="Edit"
                onClick={() => handleBulkAction('edit')}
              >
                Edit
              </Button>
              <Button
                variant="outline"
                size="sm"
                iconName="Download"
                onClick={() => handleBulkAction('download')}
              >
                Download
              </Button>
              <Button
                variant="destructive"
                size="sm"
                iconName="Trash2"
                onClick={() => handleBulkAction('delete')}
              >
                Delete
              </Button>
            </div>
          </div>
        )}
      </div>
      {/* Video Grid */}
      <div className="p-6">
        {filteredVideos?.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center mb-4">
              <Icon name="Video" size={32} className="text-text-secondary" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-2">No videos found</h3>
            <p className="text-text-secondary">
              {searchQuery ? 'Try adjusting your search terms' : 'Upload your first video to get started'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredVideos?.map((video) => (
              <div
                key={video?.id}
                className="bg-background border border-border rounded-lg overflow-hidden hover:shadow-elevated transition-all duration-200"
              >
                {/* Thumbnail */}
                <div className="relative aspect-video">
                  <Image
                    src={video?.thumbnail}
                    alt={video?.title}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Duration */}
                  <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded">
                    {video?.duration}
                  </div>
                  
                  {/* Selection Checkbox */}
                  <div className="absolute top-2 left-2">
                    <Checkbox
                      checked={selectedVideos?.includes(video?.id)}
                      onChange={() => handleVideoSelect(video?.id)}
                      className="bg-white/90"
                    />
                  </div>
                  
                  {/* Status Badge */}
                  <div className="absolute top-2 right-2">
                    <div className={`flex items-center space-x-1 bg-white/90 px-2 py-1 rounded text-xs ${getStatusColor(video?.status)}`}>
                      <Icon name={getStatusIcon(video?.status)} size={12} />
                      <span className="capitalize">{video?.status}</span>
                    </div>
                  </div>
                </div>

                {/* Video Info */}
                <div className="p-4">
                  <h3 className="font-medium text-foreground mb-2 line-clamp-2">
                    {video?.title}
                  </h3>
                  
                  {/* Stats */}
                  <div className="flex items-center justify-between text-sm text-text-secondary mb-3">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Icon name="Eye" size={14} />
                        <span>{formatNumber(video?.views)}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Icon name="ThumbsUp" size={14} />
                        <span>{formatNumber(video?.likes)}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Icon name="MessageSquare" size={14} />
                        <span>{formatNumber(video?.comments)}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name={getPrivacyIcon(video?.privacy)} size={14} />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-text-secondary">
                      {formatDate(video?.uploadDate)}
                    </span>
                    
                    {/* Action Menu */}
                    <div className="flex items-center space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        iconName="Edit"
                        onClick={() => onEditVideo(video)}
                        className="h-8 w-8"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        iconName="BarChart3"
                        className="h-8 w-8"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        iconName="MoreVertical"
                        className="h-8 w-8"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoLibrary;