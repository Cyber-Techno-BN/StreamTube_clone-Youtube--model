import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import MainHeader from '../../components/ui/MainHeader';
import VideoPlayerControls from './components/VideoPlayerControls';
import VideoMetadata from './components/VideoMetadata';
import CommentsSection from './components/CommentsSection';
import RelatedVideos from './components/RelatedVideos';
import MiniPlayer from './components/MiniPlayer';
import LiveChat from './components/LiveChat';


import Button from '../../components/ui/Button';

const VideoPlayer = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const videoId = searchParams?.get('v') || 'default';
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(3600); // 1 hour default
  const [volume, setVolume] = useState(1);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [quality, setQuality] = useState('1080p');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [autoplayEnabled, setAutoplayEnabled] = useState(true);
  const [showMiniPlayer, setShowMiniPlayer] = useState(false);
  const [showLiveChat, setShowLiveChat] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  const videoRef = useRef(null);
  const playerRef = useRef(null);
  const controlsTimeoutRef = useRef(null);

  // Mock video data
  const mockVideo = {
    id: videoId,
    title: "Complete React Tutorial 2024 - Build Modern Web Applications",
    description: `Learn React from scratch in this comprehensive tutorial! This course covers everything you need to know to build modern web applications with React 18.\n\nWhat you'll learn:\n• React fundamentals and JSX\n• Components and Props\n• State and Event Handling\n• Hooks (useState, useEffect, useContext)\n• React Router for navigation\n• API integration with Axios\n• State management with Redux\n• Testing React applications\n• Deployment strategies\n\nPerfect for beginners and intermediate developers looking to master React development. All source code is available in the description below.\n\n🔗 Source Code: https://github.com/example/react-tutorial\n📚 Documentation: https://reactjs.org\n💬 Join our Discord: https://discord.gg/example`,
    thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=1280&h=720&fit=crop",
    duration: 3600,
    views: 1250000,
    likes: 45000,
    publishedAt: "2024-01-15T10:00:00Z",
    userReaction: null,
    hashtags: ["react", "javascript", "webdevelopment", "tutorial", "programming"],
    isLive: false,
    channel: {
      id: "tech-academy",
      name: "Tech Academy",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
      subscribers: 850000,
      verified: true
    }
  };

  // Mock comments data
  const mockComments = [
    {
      id: 1,
      user: {
        name: "Sarah Johnson",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face"
      },
      content: "This is exactly what I needed! The explanation of hooks is so clear and easy to understand. Thank you for this amazing tutorial!",
      likes: 234,
      userLiked: false,
      createdAt: "2024-01-16T14:30:00Z",
      replies: [
        {
          id: 11,
          user: {
            name: "Mike Chen",
            avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=32&h=32&fit=crop&crop=face"
          },
          content: "I agree! The useState examples were particularly helpful.",
          likes: 12,
          userLiked: false,
          createdAt: "2024-01-16T15:45:00Z"
        }
      ]
    },
    {
      id: 2,
      user: {
        name: "Alex Rodriguez",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face"
      },
      content: "Great tutorial! Could you make a follow-up video about React performance optimization?",
      likes: 89,
      userLiked: true,
      createdAt: "2024-01-16T16:20:00Z",
      replies: []
    },
    {
      id: 3,
      user: {
        name: "Emma Wilson",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face"
      },
      content: "I\'m a complete beginner and this tutorial made React so much easier to understand. The step-by-step approach is perfect!",
      likes: 156,
      userLiked: false,
      createdAt: "2024-01-16T18:10:00Z",
      replies: []
    }
  ];

  // Mock related videos
  const mockRelatedVideos = [
    {
      id: "react-hooks-deep-dive",
      title: "React Hooks Deep Dive - Advanced Patterns and Best Practices",
      thumbnail: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=320&h=180&fit=crop",
      duration: 2400,
      views: 890000,
      publishedAt: "2024-01-10T12:00:00Z",
      channel: {
        name: "Tech Academy",
        verified: true
      }
    },
    {
      id: "react-router-tutorial",
      title: "React Router 6 Complete Guide - Navigation Made Easy",
      thumbnail: "https://images.unsplash.com/photo-1551650975-87deedd944c3?w=320&h=180&fit=crop",
      duration: 1800,
      views: 650000,
      publishedAt: "2024-01-08T14:30:00Z",
      channel: {
        name: "Code Masters",
        verified: false
      }
    },
    {
      id: "redux-toolkit-guide",
      title: "Redux Toolkit - Modern State Management for React Apps",
      thumbnail: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?w=320&h=180&fit=crop",
      duration: 3200,
      views: 420000,
      publishedAt: "2024-01-05T16:45:00Z",
      channel: {
        name: "Dev Tutorials",
        verified: true
      }
    }
  ];

  // Mock live chat messages
  const mockChatMessages = [
    {
      id: 1,
      user: {
        name: "ChatUser1",
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=24&h=24&fit=crop&crop=face",
        isModerator: false,
        isSubscriber: true
      },
      content: "Great explanation of useEffect!",
      timestamp: new Date()
    },
    {
      id: 2,
      user: {
        name: "ModeratorUser",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=24&h=24&fit=crop&crop=face",
        isModerator: true,
        isSubscriber: false
      },
      content: "Welcome everyone to the live stream!",
      timestamp: new Date()
    }
  ];

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Auto-hide controls
  useEffect(() => {
    const resetControlsTimeout = () => {
      if (controlsTimeoutRef?.current) {
        clearTimeout(controlsTimeoutRef?.current);
      }
      setShowControls(true);
      controlsTimeoutRef.current = setTimeout(() => {
        if (isPlaying) {
          setShowControls(false);
        }
      }, 3000);
    };

    if (isPlaying) {
      resetControlsTimeout();
    } else {
      setShowControls(true);
    }

    return () => {
      if (controlsTimeoutRef?.current) {
        clearTimeout(controlsTimeoutRef?.current);
      }
    };
  }, [isPlaying]);

  // Simulate video progress
  useEffect(() => {
    let interval;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => Math.min(prev + 1, duration));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, duration]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (time) => {
    setCurrentTime(time);
  };

  const handleVolumeChange = (newVolume) => {
    setVolume(newVolume);
  };

  const handleSpeedChange = (speed) => {
    setPlaybackSpeed(speed);
  };

  const handleQualityChange = (newQuality) => {
    setQuality(newQuality);
  };

  const handleFullscreen = () => {
    if (!document.fullscreenElement) {
      playerRef?.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handlePictureInPicture = async () => {
    if (videoRef?.current) {
      try {
        await videoRef?.current?.requestPictureInPicture();
      } catch (error) {
        console.log('Picture-in-picture not supported');
      }
    }
  };

  const handleSubscribe = () => {
    setIsSubscribed(!isSubscribed);
  };

  const handleLike = () => {
    // Handle like functionality
    console.log('Video liked');
  };

  const handleDislike = () => {
    // Handle dislike functionality
    console.log('Video disliked');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: mockVideo?.title,
        url: window.location?.href
      });
    } else {
      navigator.clipboard?.writeText(window.location?.href);
      alert('Link copied to clipboard!');
    }
  };

  const handleAddComment = (comment) => {
    console.log('Adding comment:', comment);
  };

  const handleReplyComment = (parentId, reply) => {
    console.log('Replying to comment:', parentId, reply);
  };

  const handleLikeComment = (commentId) => {
    console.log('Liking comment:', commentId);
  };

  const handleToggleAutoplay = () => {
    setAutoplayEnabled(!autoplayEnabled);
  };

  const handleSendChatMessage = (message) => {
    console.log('Sending chat message:', message);
  };

  const handleToggleChat = () => {
    setShowLiveChat(!showLiveChat);
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef?.current) {
      clearTimeout(controlsTimeoutRef?.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} user={{ name: "John Doe", email: "john@example.com" }} />
      <div className="pt-14 md:pt-16">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {/* Video Player */}
              <div 
                ref={playerRef}
                className="relative aspect-video bg-black rounded-lg overflow-hidden mb-4"
                onMouseMove={handleMouseMove}
              >
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  poster={mockVideo?.thumbnail}
                  onClick={handlePlayPause}
                />
                
                {/* Video Overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  {!isPlaying && (
                    <Button
                      variant="ghost"
                      size="icon"
                      iconName="Play"
                      onClick={handlePlayPause}
                      className="text-white hover:bg-white/20 w-16 h-16 md:w-20 md:h-20"
                    />
                  )}
                </div>

                {/* Video Controls */}
                {showControls && (
                  <VideoPlayerControls
                    isPlaying={isPlaying}
                    onPlayPause={handlePlayPause}
                    currentTime={currentTime}
                    duration={duration}
                    onSeek={handleSeek}
                    volume={volume}
                    onVolumeChange={handleVolumeChange}
                    playbackSpeed={playbackSpeed}
                    onSpeedChange={handleSpeedChange}
                    quality={quality}
                    onQualityChange={handleQualityChange}
                    onFullscreen={handleFullscreen}
                    onPictureInPicture={handlePictureInPicture}
                  />
                )}

                {/* Mobile Back Button */}
                {isMobile && (
                  <div className="absolute top-4 left-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      iconName="ArrowLeft"
                      onClick={() => navigate(-1)}
                      className="text-white hover:bg-white/20"
                    />
                  </div>
                )}

                {/* Mobile Share Button */}
                {isMobile && (
                  <div className="absolute top-4 right-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      iconName="Share"
                      onClick={handleShare}
                      className="text-white hover:bg-white/20"
                    />
                  </div>
                )}
              </div>

              {/* Video Metadata */}
              <VideoMetadata
                video={mockVideo}
                isSubscribed={isSubscribed}
                onSubscribe={handleSubscribe}
                onLike={handleLike}
                onDislike={handleDislike}
                onShare={handleShare}
              />

              {/* Comments Section */}
              <CommentsSection
                comments={mockComments}
                onAddComment={handleAddComment}
                onReplyComment={handleReplyComment}
                onLikeComment={handleLikeComment}
              />
            </div>

            {/* Sidebar - Desktop */}
            <div className="hidden lg:block">
              <RelatedVideos
                videos={mockRelatedVideos}
                autoplayEnabled={autoplayEnabled}
                onToggleAutoplay={handleToggleAutoplay}
              />
            </div>
          </div>

          {/* Related Videos - Mobile */}
          {isMobile && (
            <div className="mt-6">
              <RelatedVideos
                videos={mockRelatedVideos}
                autoplayEnabled={autoplayEnabled}
                onToggleAutoplay={handleToggleAutoplay}
              />
            </div>
          )}
        </div>
      </div>
      {/* Mini Player */}
      <MiniPlayer
        video={mockVideo}
        isPlaying={isPlaying}
        onPlayPause={handlePlayPause}
        onClose={() => setShowMiniPlayer(false)}
        onExpand={() => navigate(`/video-player?v=${mockVideo?.id}`)}
        isVisible={showMiniPlayer}
      />
      {/* Live Chat */}
      {mockVideo?.isLive && (
        <LiveChat
          isLive={mockVideo?.isLive}
          messages={mockChatMessages}
          onSendMessage={handleSendChatMessage}
          onToggleChat={handleToggleChat}
        />
      )}
    </div>
  );
};

export default VideoPlayer;