import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const RelatedVideos = ({ videos, autoplayEnabled, onToggleAutoplay }) => {
  const navigate = useNavigate();

  const formatViews = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000)?.toFixed(1)}M`;
    } else if (views >= 1000) {
      return `${(views / 1000)?.toFixed(1)}K`;
    }
    return views?.toString();
  };

  const formatDuration = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
  };

  const formatTimeAgo = (date) => {
    const now = new Date();
    const videoDate = new Date(date);
    const diffTime = Math.abs(now - videoDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return '1 day ago';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  };

  const handleVideoClick = (videoId) => {
    navigate(`/video-player?v=${videoId}`);
  };

  return (
    <div className="bg-background">
      {/* Autoplay Toggle */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-semibold text-foreground">Up next</h3>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-text-secondary">Autoplay</span>
          <button
            onClick={onToggleAutoplay}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 ${
              autoplayEnabled ? 'bg-primary' : 'bg-muted'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
                autoplayEnabled ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>
      {/* Related Videos List */}
      <div className="space-y-3 p-4">
        {videos?.map((video, index) => (
          <div
            key={video?.id}
            onClick={() => handleVideoClick(video?.id)}
            className="flex space-x-3 cursor-pointer hover:bg-muted rounded-lg p-2 transition-colors duration-200"
          >
            {/* Thumbnail */}
            <div className="relative flex-shrink-0">
              <div className="w-40 h-24 md:w-44 md:h-28 rounded-lg overflow-hidden bg-muted">
                <Image
                  src={video?.thumbnail}
                  alt={video?.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Duration Badge */}
              <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1 py-0.5 rounded">
                {formatDuration(video?.duration)}
              </div>

              {/* Queue Number for First Video */}
              {index === 0 && autoplayEnabled && (
                <div className="absolute top-1 left-1 bg-primary text-white text-xs px-2 py-1 rounded flex items-center space-x-1">
                  <Icon name="Play" size={12} />
                  <span>UP NEXT</span>
                </div>
              )}
            </div>

            {/* Video Info */}
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-foreground text-sm leading-tight line-clamp-2 mb-1">
                {video?.title}
              </h4>
              
              <div className="flex items-center space-x-1 mb-1">
                <span className="text-text-secondary text-xs hover:text-foreground cursor-pointer">
                  {video?.channel?.name}
                </span>
                {video?.channel?.verified && (
                  <Icon name="CheckCircle" size={12} className="text-primary" />
                )}
              </div>
              
              <div className="flex items-center space-x-1 text-text-secondary text-xs">
                <span>{formatViews(video?.views)} views</span>
                <span>•</span>
                <span>{formatTimeAgo(video?.publishedAt)}</span>
              </div>
            </div>

            {/* More Options */}
            <div className="flex-shrink-0">
              <button className="p-1 hover:bg-muted rounded-full transition-colors duration-200">
                <Icon name="MoreVertical" size={16} className="text-text-secondary" />
              </button>
            </div>
          </div>
        ))}
      </div>
      {/* Load More */}
      <div className="p-4 border-t border-border">
        <button className="w-full py-2 text-primary text-sm font-medium hover:bg-muted rounded-lg transition-colors duration-200">
          Show more
        </button>
      </div>
    </div>
  );
};

export default RelatedVideos;