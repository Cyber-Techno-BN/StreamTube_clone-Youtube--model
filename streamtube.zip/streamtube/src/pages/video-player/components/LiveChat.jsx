import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const LiveChat = ({ isLive, messages, onSendMessage, onToggleChat }) => {
  const [newMessage, setNewMessage] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef?.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (newMessage?.trim()) {
      onSendMessage(newMessage);
      setNewMessage('');
    }
  };

  const handleKeyPress = (e) => {
    if (e?.key === 'Enter' && !e?.shiftKey) {
      e?.preventDefault();
      handleSendMessage();
    }
  };

  if (!isLive) return null;

  return (
    <div className={`fixed right-4 top-20 bg-card border border-border rounded-lg shadow-elevated z-40 transition-all duration-300 ${
      isExpanded ? 'w-80 h-96' : 'w-80 h-12'
    }`}>
      {/* Chat Header */}
      <div className="flex items-center justify-between p-3 border-b border-border">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
          <span className="text-sm font-medium text-card-foreground">Live Chat</span>
          <span className="text-xs text-text-secondary">({messages?.length})</span>
        </div>
        <div className="flex items-center space-x-1">
          <Button
            variant="ghost"
            size="icon"
            iconName={isExpanded ? "ChevronDown" : "ChevronUp"}
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-6 h-6"
          />
          <Button
            variant="ghost"
            size="icon"
            iconName="X"
            onClick={onToggleChat}
            className="w-6 h-6"
          />
        </div>
      </div>
      {isExpanded && (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2 h-64">
            {messages?.map((message) => (
              <div key={message?.id} className="flex space-x-2">
                <div className="w-6 h-6 rounded-full overflow-hidden bg-muted flex-shrink-0">
                  <Image
                    src={message?.user?.avatar}
                    alt={message?.user?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-medium text-card-foreground truncate">
                      {message?.user?.name}
                    </span>
                    {message?.user?.isModerator && (
                      <Icon name="Shield" size={12} className="text-primary" />
                    )}
                    {message?.user?.isSubscriber && (
                      <Icon name="Star" size={12} className="text-warning" />
                    )}
                  </div>
                  <p className="text-xs text-card-foreground leading-relaxed break-words">
                    {message?.content}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input */}
          <div className="p-3 border-t border-border">
            <div className="flex space-x-2">
              <Input
                type="text"
                placeholder="Say something..."
                value={newMessage}
                onChange={(e) => setNewMessage(e?.target?.value)}
                onKeyPress={handleKeyPress}
                className="flex-1 text-sm"
              />
              <Button
                variant="default"
                size="sm"
                iconName="Send"
                onClick={handleSendMessage}
                disabled={!newMessage?.trim()}
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default LiveChat;