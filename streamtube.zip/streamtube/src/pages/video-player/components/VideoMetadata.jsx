import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const VideoMetadata = ({ video, isSubscribed, onSubscribe, onLike, onDislike, onShare }) => {
  const navigate = useNavigate();
  const [showFullDescription, setShowFullDescription] = useState(false);

  const formatViews = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000)?.toFixed(1)}M`;
    } else if (views >= 1000) {
      return `${(views / 1000)?.toFixed(1)}K`;
    }
    return views?.toString();
  };

  const formatDate = (date) => {
    const now = new Date();
    const videoDate = new Date(date);
    const diffTime = Math.abs(now - videoDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return '1 day ago';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  };

  const handleChannelClick = () => {
    navigate('/channel-profile');
  };

  return (
    <div className="bg-background p-4 md:p-6">
      {/* Video Title */}
      <h1 className="text-xl md:text-2xl font-bold text-foreground mb-4 leading-tight">
        {video?.title}
      </h1>
      {/* Channel Info and Actions */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        {/* Channel Info */}
        <div className="flex items-center space-x-3">
          <button
            onClick={handleChannelClick}
            className="flex items-center space-x-3 hover:opacity-80 transition-opacity duration-200"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full overflow-hidden bg-muted">
              <Image
                src={video?.channel?.avatar}
                alt={video?.channel?.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h3 className="font-semibold text-foreground text-sm md:text-base">
                {video?.channel?.name}
                {video?.channel?.verified && (
                  <Icon name="CheckCircle" size={16} className="inline ml-1 text-primary" />
                )}
              </h3>
              <p className="text-text-secondary text-xs md:text-sm">
                {formatViews(video?.channel?.subscribers)} subscribers
              </p>
            </div>
          </button>

          <Button
            variant={isSubscribed ? "secondary" : "default"}
            onClick={onSubscribe}
            className="ml-4"
          >
            {isSubscribed ? "Subscribed" : "Subscribe"}
          </Button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          <div className="flex items-center bg-muted rounded-full">
            <Button
              variant="ghost"
              size="sm"
              iconName="ThumbsUp"
              iconPosition="left"
              onClick={onLike}
              className={`rounded-l-full rounded-r-none border-r border-border ${
                video?.userReaction === 'like' ? 'text-primary' : ''
              }`}
            >
              {formatViews(video?.likes)}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              iconName="ThumbsDown"
              onClick={onDislike}
              className={`rounded-r-full rounded-l-none ${
                video?.userReaction === 'dislike' ? 'text-primary' : ''
              }`}
            />
          </div>

          <Button
            variant="ghost"
            size="sm"
            iconName="Share"
            iconPosition="left"
            onClick={onShare}
            className="bg-muted"
          >
            Share
          </Button>

          <Button
            variant="ghost"
            size="icon"
            iconName="MoreHorizontal"
            className="bg-muted"
          />
        </div>
      </div>
      {/* Video Stats */}
      <div className="flex items-center space-x-4 text-text-secondary text-sm mb-4">
        <span>{formatViews(video?.views)} views</span>
        <span>•</span>
        <span>{formatDate(video?.publishedAt)}</span>
      </div>
      {/* Description */}
      <div className="bg-muted rounded-lg p-4">
        <div className={`text-foreground text-sm leading-relaxed ${
          showFullDescription ? '' : 'line-clamp-3'
        }`}>
          {video?.description?.split('\n')?.map((line, index) => (
            <p key={index} className="mb-2 last:mb-0">
              {line}
            </p>
          ))}
        </div>

        {/* Hashtags */}
        {video?.hashtags && video?.hashtags?.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-3">
            {video?.hashtags?.map((hashtag, index) => (
              <span
                key={index}
                className="text-primary text-sm font-medium hover:underline cursor-pointer"
              >
                #{hashtag}
              </span>
            ))}
          </div>
        )}

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowFullDescription(!showFullDescription)}
          className="mt-3 p-0 h-auto text-text-secondary hover:text-foreground"
        >
          {showFullDescription ? 'Show less' : 'Show more'}
        </Button>
      </div>
    </div>
  );
};

export default VideoMetadata;