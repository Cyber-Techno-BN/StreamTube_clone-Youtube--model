import React, { useState, useRef, useEffect } from 'react';

import Button from '../../../components/ui/Button';

const VideoPlayerControls = ({ 
  isPlaying, 
  onPlayPause, 
  currentTime, 
  duration, 
  onSeek, 
  volume, 
  onVolumeChange, 
  playbackSpeed, 
  onSpeedChange, 
  quality, 
  onQualityChange, 
  onFullscreen,
  onPictureInPicture 
}) => {
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const progressRef = useRef(null);

  const speedOptions = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
  const qualityOptions = ['144p', '240p', '360p', '480p', '720p', '1080p'];

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds?.toString()?.padStart(2, '0')}`;
  };

  const handleProgressClick = (e) => {
    if (progressRef?.current) {
      const rect = progressRef?.current?.getBoundingClientRect();
      const clickX = e?.clientX - rect?.left;
      const newTime = (clickX / rect?.width) * duration;
      onSeek(newTime);
    }
  };

  const handleMouseDown = (e) => {
    setIsDragging(true);
    handleProgressClick(e);
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      handleProgressClick(e);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging]);

  return (
    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
      {/* Progress Bar */}
      <div className="mb-4">
        <div
          ref={progressRef}
          className="w-full h-1 bg-white/30 rounded-full cursor-pointer hover:h-2 transition-all duration-200"
          onClick={handleProgressClick}
          onMouseDown={handleMouseDown}
        >
          <div
            className="h-full bg-primary rounded-full relative"
            style={{ width: `${(currentTime / duration) * 100}%` }}
          >
            <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-3 h-3 bg-primary rounded-full opacity-0 hover:opacity-100 transition-opacity duration-200"></div>
          </div>
        </div>
      </div>
      {/* Controls */}
      <div className="flex items-center justify-between text-white">
        {/* Left Controls */}
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            iconName={isPlaying ? "Pause" : "Play"}
            onClick={onPlayPause}
            className="text-white hover:bg-white/20"
          />

          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              iconName={volume === 0 ? "VolumeX" : volume < 0.5 ? "Volume1" : "Volume2"}
              onClick={() => setShowVolumeSlider(!showVolumeSlider)}
              className="text-white hover:bg-white/20"
            />
            
            {showVolumeSlider && (
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-black/80 rounded-lg p-2">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={volume}
                  onChange={(e) => onVolumeChange(parseFloat(e?.target?.value))}
                  className="w-20 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            )}
          </div>

          <span className="text-sm font-medium">
            {formatTime(currentTime)} / {formatTime(duration)}
          </span>
        </div>

        {/* Right Controls */}
        <div className="flex items-center space-x-2">
          {/* Speed Control */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSpeedMenu(!showSpeedMenu)}
              className="text-white hover:bg-white/20 text-sm"
            >
              {playbackSpeed}x
            </Button>
            
            {showSpeedMenu && (
              <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg py-2 min-w-[80px]">
                {speedOptions?.map((speed) => (
                  <button
                    key={speed}
                    onClick={() => {
                      onSpeedChange(speed);
                      setShowSpeedMenu(false);
                    }}
                    className={`block w-full px-3 py-1 text-sm text-left hover:bg-white/20 ${
                      speed === playbackSpeed ? 'text-primary' : 'text-white'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quality Control */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowQualityMenu(!showQualityMenu)}
              className="text-white hover:bg-white/20 text-sm"
            >
              {quality}
            </Button>
            
            {showQualityMenu && (
              <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg py-2 min-w-[80px]">
                {qualityOptions?.map((q) => (
                  <button
                    key={q}
                    onClick={() => {
                      onQualityChange(q);
                      setShowQualityMenu(false);
                    }}
                    className={`block w-full px-3 py-1 text-sm text-left hover:bg-white/20 ${
                      q === quality ? 'text-primary' : 'text-white'
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}
          </div>

          <Button
            variant="ghost"
            size="icon"
            iconName="PictureInPicture"
            onClick={onPictureInPicture}
            className="text-white hover:bg-white/20"
          />

          <Button
            variant="ghost"
            size="icon"
            iconName="Maximize"
            onClick={onFullscreen}
            className="text-white hover:bg-white/20"
          />
        </div>
      </div>
    </div>
  );
};

export default VideoPlayerControls;