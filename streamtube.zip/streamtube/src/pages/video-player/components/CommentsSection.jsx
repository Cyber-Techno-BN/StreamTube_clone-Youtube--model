import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const CommentsSection = ({ comments, onAddComment, onReplyComment, onLikeComment }) => {
  const [newComment, setNewComment] = useState('');
  const [sortBy, setSortBy] = useState('top');
  const [replyingTo, setReplyingTo] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [showReplies, setShowReplies] = useState({});

  const formatTimeAgo = (date) => {
    const now = new Date();
    const commentDate = new Date(date);
    const diffTime = Math.abs(now - commentDate);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  const handleSubmitComment = () => {
    if (newComment?.trim()) {
      onAddComment(newComment);
      setNewComment('');
    }
  };

  const handleSubmitReply = (parentId) => {
    if (replyText?.trim()) {
      onReplyComment(parentId, replyText);
      setReplyText('');
      setReplyingTo(null);
    }
  };

  const toggleReplies = (commentId) => {
    setShowReplies(prev => ({
      ...prev,
      [commentId]: !prev?.[commentId]
    }));
  };

  const sortedComments = [...comments]?.sort((a, b) => {
    if (sortBy === 'top') {
      return b?.likes - a?.likes;
    } else {
      return new Date(b.createdAt) - new Date(a.createdAt);
    }
  });

  return (
    <div className="bg-background p-4 md:p-6">
      {/* Comments Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">
          {comments?.length} Comments
        </h3>
        
        <div className="flex items-center space-x-2">
          <Icon name="ArrowUpDown" size={16} className="text-text-secondary" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e?.target?.value)}
            className="bg-transparent text-text-secondary text-sm border-none outline-none cursor-pointer"
          >
            <option value="top">Top comments</option>
            <option value="newest">Newest first</option>
          </select>
        </div>
      </div>
      {/* Add Comment */}
      <div className="flex space-x-3 mb-6">
        <div className="w-10 h-10 rounded-full overflow-hidden bg-muted flex-shrink-0">
          <Image
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face"
            alt="Your avatar"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1">
          <Input
            type="text"
            placeholder="Add a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e?.target?.value)}
            className="border-0 border-b-2 border-border rounded-none bg-transparent px-0 focus:border-primary"
          />
          <div className="flex items-center justify-end space-x-2 mt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setNewComment('')}
              disabled={!newComment?.trim()}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={handleSubmitComment}
              disabled={!newComment?.trim()}
            >
              Comment
            </Button>
          </div>
        </div>
      </div>
      {/* Comments List */}
      <div className="space-y-6">
        {sortedComments?.map((comment) => (
          <div key={comment?.id} className="space-y-4">
            {/* Main Comment */}
            <div className="flex space-x-3">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-muted flex-shrink-0">
                <Image
                  src={comment?.user?.avatar}
                  alt={comment?.user?.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="font-medium text-foreground text-sm">
                    {comment?.user?.name}
                  </span>
                  <span className="text-text-secondary text-xs">
                    {formatTimeAgo(comment?.createdAt)}
                  </span>
                </div>
                <p className="text-foreground text-sm leading-relaxed mb-2">
                  {comment?.content}
                </p>
                <div className="flex items-center space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="ThumbsUp"
                    iconPosition="left"
                    onClick={() => onLikeComment(comment?.id)}
                    className={`text-xs h-8 ${
                      comment?.userLiked ? 'text-primary' : 'text-text-secondary'
                    }`}
                  >
                    {comment?.likes}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="ThumbsDown"
                    className="text-xs h-8 text-text-secondary"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setReplyingTo(comment?.id)}
                    className="text-xs h-8 text-text-secondary"
                  >
                    Reply
                  </Button>
                </div>

                {/* Reply Input */}
                {replyingTo === comment?.id && (
                  <div className="flex space-x-3 mt-4">
                    <div className="w-8 h-8 rounded-full overflow-hidden bg-muted flex-shrink-0">
                      <Image
                        src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face"
                        alt="Your avatar"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <Input
                        type="text"
                        placeholder="Add a reply..."
                        value={replyText}
                        onChange={(e) => setReplyText(e?.target?.value)}
                        className="border-0 border-b-2 border-border rounded-none bg-transparent px-0 focus:border-primary text-sm"
                      />
                      <div className="flex items-center justify-end space-x-2 mt-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setReplyingTo(null);
                            setReplyText('');
                          }}
                        >
                          Cancel
                        </Button>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleSubmitReply(comment?.id)}
                          disabled={!replyText?.trim()}
                        >
                          Reply
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Replies */}
            {comment?.replies && comment?.replies?.length > 0 && (
              <div className="ml-13">
                <Button
                  variant="ghost"
                  size="sm"
                  iconName={showReplies?.[comment?.id] ? "ChevronUp" : "ChevronDown"}
                  iconPosition="left"
                  onClick={() => toggleReplies(comment?.id)}
                  className="text-primary text-sm mb-3"
                >
                  {showReplies?.[comment?.id] ? 'Hide' : 'Show'} {comment?.replies?.length} replies
                </Button>

                {showReplies?.[comment?.id] && (
                  <div className="space-y-4">
                    {comment?.replies?.map((reply) => (
                      <div key={reply?.id} className="flex space-x-3">
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-muted flex-shrink-0">
                          <Image
                            src={reply?.user?.avatar}
                            alt={reply?.user?.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium text-foreground text-sm">
                              {reply?.user?.name}
                            </span>
                            <span className="text-text-secondary text-xs">
                              {formatTimeAgo(reply?.createdAt)}
                            </span>
                          </div>
                          <p className="text-foreground text-sm leading-relaxed mb-2">
                            {reply?.content}
                          </p>
                          <div className="flex items-center space-x-4">
                            <Button
                              variant="ghost"
                              size="sm"
                              iconName="ThumbsUp"
                              iconPosition="left"
                              className={`text-xs h-8 ${
                                reply?.userLiked ? 'text-primary' : 'text-text-secondary'
                              }`}
                            >
                              {reply?.likes}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              iconName="ThumbsDown"
                              className="text-xs h-8 text-text-secondary"
                            />
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-xs h-8 text-text-secondary"
                            >
                              Reply
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommentsSection;