import React from 'react';

import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const MiniPlayer = ({ 
  video, 
  isPlaying, 
  onPlayPause, 
  onClose, 
  onExpand, 
  isVisible 
}) => {
  if (!isVisible || !video) return null;

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-card border border-border rounded-lg shadow-elevated z-50 animate-slideUp">
      {/* Video Player */}
      <div className="relative aspect-video bg-black rounded-t-lg overflow-hidden">
        <Image
          src={video?.thumbnail}
          alt={video?.title}
          className="w-full h-full object-cover"
        />
        
        {/* Play/Pause Overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
          <Button
            variant="ghost"
            size="icon"
            iconName={isPlaying ? "Pause" : "Play"}
            onClick={onPlayPause}
            className="text-white hover:bg-white/20 w-12 h-12"
          />
        </div>

        {/* Close Button */}
        <Button
          variant="ghost"
          size="icon"
          iconName="X"
          onClick={onClose}
          className="absolute top-2 right-2 text-white hover:bg-white/20 w-8 h-8"
        />
      </div>
      {/* Video Info */}
      <div 
        className="p-3 cursor-pointer hover:bg-muted transition-colors duration-200"
        onClick={onExpand}
      >
        <h4 className="font-medium text-card-foreground text-sm leading-tight line-clamp-2 mb-1">
          {video?.title}
        </h4>
        <p className="text-text-secondary text-xs">
          {video?.channel?.name}
        </p>
      </div>
    </div>
  );
};

export default MiniPlayer;