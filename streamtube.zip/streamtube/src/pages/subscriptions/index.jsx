import React, { useState } from 'react';
import MainHeader from '../../components/ui/MainHeader';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const Subscriptions = () => {
  const [selectedView, setSelectedView] = useState('all');

  // Mock user data
  const mockUser = {
    name: "Alex Johnson",
    email: "alex.johnson@example.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"
  };

  const viewOptions = [
    { id: 'all', label: 'All', icon: 'Grid3X3' },
    { id: 'today', label: 'Today', icon: 'Clock' },
    { id: 'unwatched', label: 'Unwatched', icon: 'Eye' },
  ];

  // Mock subscriptions data
  const mockSubscriptions = [
    {
      id: "s1",
      channelId: "c1",
      name: "CodeMaster Pro",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&h=400&fit=crop&crop=face",
      isVerified: true,
      subscribers: "850K",
      isLive: false,
      latestVideo: {
        id: "v1",
        title: "Advanced React Patterns You Need to Know",
        thumbnail: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop",
        duration: 1456,
        views: 234567,
        publishedAt: "2024-01-16T10:00:00Z",
        isWatched: false
      }
    },
    {
      id: "s2",
      channelId: "c2", 
      name: "Gaming Central",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
      isVerified: true,
      subscribers: "2.1M",
      isLive: true,
      latestVideo: {
        id: "v2",
        title: "🔴 LIVE: Epic Battle Royale Tournament Finals",
        thumbnail: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400&h=225&fit=crop",
        duration: 0, // Live stream
        views: 15234,
        publishedAt: "2024-01-16T14:30:00Z",
        isWatched: false,
        isLive: true
      }
    },
    {
      id: "s3",
      channelId: "c3",
      name: "Music Vibes", 
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
      isVerified: true,
      subscribers: "3.2M",
      isLive: false,
      latestVideo: {
        id: "v3",
        title: "Chill Lo-Fi Beats for Studying and Relaxation",
        thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=225&fit=crop",
        duration: 3600,
        views: 987654,
        publishedAt: "2024-01-15T20:00:00Z",
        isWatched: true
      }
    },
    {
      id: "s4",
      channelId: "c4",
      name: "Tech News Daily",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
      isVerified: true,
      subscribers: "1.5M",
      isLive: false,
      latestVideo: {
        id: "v4",
        title: "Apple\'s Secret Project Revealed - Industry Changing!",
        thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=225&fit=crop",
        duration: 567,
        views: 567890,
        publishedAt: "2024-01-16T08:15:00Z",
        isWatched: false
      }
    },
    {
      id: "s5",
      channelId: "c5",
      name: "Nature Explorer",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
      isVerified: false,
      subscribers: "925K",
      isLive: false,
      latestVideo: {
        id: "v5",
        title: "Incredible Wildlife Photography - Behind the Scenes",
        thumbnail: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&h=225&fit=crop",
        duration: 1234,
        views: 345678,
        publishedAt: "2024-01-14T16:45:00Z",
        isWatched: true
      }
    }
  ];

  const formatDuration = (seconds) => {
    if (seconds === 0) return "LIVE";
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
  };

  const formatViews = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000)?.toFixed(1)}M views`;
    }
    if (views >= 1000) {
      return `${(views / 1000)?.toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const formatTimeAgo = (publishedAt) => {
    const now = new Date();
    const published = new Date(publishedAt);
    const diffInHours = Math.floor((now - published) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return "Just now";
    }
    if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  const isToday = (publishedAt) => {
    const today = new Date();
    const published = new Date(publishedAt);
    return today?.toDateString() === published?.toDateString();
  };

  const filteredSubscriptions = mockSubscriptions?.filter(sub => {
    if (selectedView === 'today') {
      return isToday(sub?.latestVideo?.publishedAt);
    }
    if (selectedView === 'unwatched') {
      return !sub?.latestVideo?.isWatched;
    }
    return true; // 'all'
  });

  const handleVideoClick = (videoId) => {
    window.location.href = `/video-player?v=${videoId}`;
  };

  const handleChannelClick = (channelId) => {
    window.location.href = `/channel-profile?c=${channelId}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} user={mockUser} />
      <main className="pt-14 md:pt-16">
        {/* Header */}
        <div className="border-b border-border">
          <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
            <div className="flex items-center gap-3 mb-6">
              <Icon name="Users" size={32} className="text-primary" />
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">Subscriptions</h1>
            </div>

            {/* View Options */}
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
              {viewOptions?.map((option) => (
                <Button
                  key={option?.id}
                  variant={selectedView === option?.id ? "primary" : "ghost"}
                  onClick={() => setSelectedView(option?.id)}
                  className="whitespace-nowrap flex-shrink-0"
                >
                  <Icon name={option?.icon} size={16} className="mr-2" />
                  {option?.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Subscribed Channels Bar */}
        <div className="border-b border-border bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 md:px-6 py-4">
            <div className="flex items-center gap-4 overflow-x-auto scrollbar-hide">
              {mockSubscriptions?.map((channel) => (
                <button
                  key={channel?.id}
                  onClick={() => handleChannelClick(channel?.channelId)}
                  className="flex flex-col items-center gap-2 flex-shrink-0 hover:opacity-80 transition-opacity duration-200"
                >
                  <div className="relative">
                    <img
                      src={channel?.avatar}
                      alt={channel?.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    {channel?.isLive && (
                      <div className="absolute -bottom-1 -right-1 bg-red-500 text-white text-xs px-1 rounded">
                        LIVE
                      </div>
                    )}
                  </div>
                  <span className="text-xs text-text-secondary max-w-[60px] truncate">
                    {channel?.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Latest Videos */}
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
          <h2 className="text-lg font-medium text-foreground mb-4">
            Latest from your subscriptions
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
            {filteredSubscriptions?.map((subscription) => (
              <div
                key={subscription?.id}
                className="group cursor-pointer"
                onClick={() => handleVideoClick(subscription?.latestVideo?.id)}
              >
                {/* Thumbnail */}
                <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                  <img
                    src={subscription?.latestVideo?.thumbnail}
                    alt={subscription?.latestVideo?.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                  
                  {/* Duration/Live Badge */}
                  <div className={`absolute bottom-2 right-2 text-white text-xs px-2 py-1 rounded ${
                    subscription?.latestVideo?.isLive ? 'bg-red-500' : 'bg-black bg-opacity-80'
                  }`}>
                    {formatDuration(subscription?.latestVideo?.duration)}
                  </div>

                  {/* Watched Indicator */}
                  {subscription?.latestVideo?.isWatched && !subscription?.latestVideo?.isLive && (
                    <div className="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded">
                      Watched
                    </div>
                  )}
                </div>

                {/* Video Info */}
                <div className="flex gap-3 mt-3">
                  {/* Channel Avatar */}
                  <button
                    onClick={(e) => {
                      e?.stopPropagation();
                      handleChannelClick(subscription?.channelId);
                    }}
                    className="flex-shrink-0"
                  >
                    <img
                      src={subscription?.avatar}
                      alt={subscription?.name}
                      className="w-9 h-9 rounded-full object-cover"
                    />
                  </button>

                  {/* Video Details */}
                  <div className="min-w-0 flex-1">
                    <h3 className="font-medium text-sm text-foreground line-clamp-2 group-hover:text-primary transition-colors duration-200">
                      {subscription?.latestVideo?.title}
                    </h3>
                    
                    <button
                      onClick={(e) => {
                        e?.stopPropagation();
                        handleChannelClick(subscription?.channelId);
                      }}
                      className="flex items-center gap-1 mt-1 text-text-secondary hover:text-foreground transition-colors duration-200"
                    >
                      <span className="text-sm">{subscription?.name}</span>
                      {subscription?.isVerified && (
                        <Icon name="CheckCircle" size={12} className="text-primary" />
                      )}
                    </button>
                    
                    <div className="flex items-center gap-1 mt-1 text-xs text-text-secondary">
                      <span>
                        {subscription?.latestVideo?.isLive 
                          ? `${subscription?.latestVideo?.views} watching`
                          : formatViews(subscription?.latestVideo?.views)
                        }
                      </span>
                      <span>•</span>
                      <span>{formatTimeAgo(subscription?.latestVideo?.publishedAt)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* No Results Message */}
          {filteredSubscriptions?.length === 0 && (
            <div className="text-center py-12">
              <Icon name="Users" size={48} className="mx-auto text-text-secondary mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                No videos found
              </h3>
              <p className="text-text-secondary">
                {selectedView === 'today' && "No new videos today from your subscriptions."}
                {selectedView === 'unwatched' && "You've watched all recent videos!"}
                {selectedView === 'all' && "Subscribe to channels to see their latest videos here."}
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Subscriptions;