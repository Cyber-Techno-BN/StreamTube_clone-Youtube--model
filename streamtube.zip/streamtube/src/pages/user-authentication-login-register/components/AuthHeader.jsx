import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const AuthHeader = () => {
  const navigate = useNavigate();

  const handleLogoClick = () => {
    navigate('/');
  };

  return (
    <div className="text-center mb-8">
      <button
        onClick={handleLogoClick}
        className="inline-flex items-center space-x-3 hover:opacity-80 transition-opacity duration-200 mb-4"
      >
        <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
          <Icon name="Play" size={24} color="white" />
        </div>
        <div className="text-left">
          <h1 className="text-2xl font-bold text-foreground">StreamTube</h1>
          <p className="text-sm text-text-secondary">Your Video Universe</p>
        </div>
      </button>
      
      <div className="space-y-2">
        <h2 className="text-xl font-semibold text-foreground">
          Welcome to StreamTube
        </h2>
        <p className="text-text-secondary">
          Join millions of creators and viewers in the ultimate video streaming experience
        </p>
      </div>
    </div>
  );
};

export default AuthHeader;