import React, { useEffect, useRef } from 'react';

const BackgroundVideo = () => {
  const videoRef = useRef(null);

  const videoSources = [
    "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg",
    "https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg",
    "https://images.pexels.com/photos/1181248/pexels-photo-1181248.jpeg",
    "https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      if (videoRef?.current) {
        const randomIndex = Math.floor(Math.random() * videoSources?.length);
        videoRef.current.style.backgroundImage = `url(${videoSources?.[randomIndex]})`;
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="hidden lg:block absolute inset-0 overflow-hidden">
      <div
        ref={videoRef}
        className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-all duration-1000"
        style={{
          backgroundImage: `url(${videoSources?.[0]})`,
        }}
      >
        <div className="absolute inset-0 bg-black/60"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-transparent"></div>
      </div>
      {/* Floating video previews */}
      <div className="absolute top-20 right-20 w-48 h-28 bg-card rounded-lg shadow-lg overflow-hidden opacity-80">
        <div className="w-full h-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
          <div className="text-center">
            <div className="w-8 h-8 bg-primary/30 rounded-full flex items-center justify-center mx-auto mb-2">
              <div className="w-3 h-3 bg-white rounded-full"></div>
            </div>
            <p className="text-xs text-text-secondary">Live Stream</p>
          </div>
        </div>
      </div>
      <div className="absolute bottom-32 right-32 w-40 h-24 bg-card rounded-lg shadow-lg overflow-hidden opacity-70">
        <div className="w-full h-full bg-gradient-to-br from-accent/20 to-success/20 flex items-center justify-center">
          <div className="text-center">
            <div className="w-6 h-6 bg-accent/30 rounded mx-auto mb-1">
              <div className="w-full h-full flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-sm"></div>
              </div>
            </div>
            <p className="text-xs text-text-secondary">Tutorial</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackgroundVideo;