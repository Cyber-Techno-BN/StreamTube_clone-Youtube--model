import React, { useState } from 'react';
import AuthHeader from './components/AuthHeader';
import AuthTabs from './components/AuthTabs';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import SocialLogin from './components/SocialLogin';
import BackgroundVideo from './components/BackgroundVideo';

const UserAuthenticationPage = () => {
  const [activeTab, setActiveTab] = useState('login');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
    // Additional success handling can be added here
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <BackgroundVideo />
      
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-card/95 backdrop-blur-sm border border-border rounded-2xl shadow-2xl p-8">
            <AuthHeader />
            
            <div className="space-y-6">
              <AuthTabs activeTab={activeTab} onTabChange={setActiveTab} />
              
              <div className="space-y-6">
                {activeTab === 'login' ? (
                  <LoginForm onSuccess={handleAuthSuccess} />
                ) : (
                  <RegisterForm onSuccess={handleAuthSuccess} />
                )}
                
                <SocialLogin onSuccess={handleAuthSuccess} />
              </div>
            </div>
          </div>
          
          {/* Additional Info */}
          <div className="mt-6 text-center">
            <div className="bg-card/80 backdrop-blur-sm border border-border rounded-lg p-4">
              <h3 className="text-sm font-medium text-foreground mb-2">
                Join the StreamTube Community
              </h3>
              <div className="flex items-center justify-center space-x-6 text-xs text-text-secondary">
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span>10M+ Videos</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span>5M+ Creators</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-accent rounded-full"></div>
                  <span>100M+ Views</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserAuthenticationPage;