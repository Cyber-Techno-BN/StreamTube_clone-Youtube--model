import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import MainHeader from '../../components/ui/MainHeader';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import SettingsTabs from './components/SettingsTabs';
import ProfileSection from './components/ProfileSection';
import PrivacySettings from './components/PrivacySettings';
import NotificationSettings from './components/NotificationSettings';
import PlaybackSettings from './components/PlaybackSettings';
import SecuritySettings from './components/SecuritySettings';

const UserProfileSettings = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('profile');
  const [isLoading, setIsLoading] = useState(false);

  // Mock user data
  const [user] = useState({
    id: 1,
    name: "Alex Johnson",
    email: "alex.johnson@example.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    bio: "Content creator passionate about technology, gaming, and education. Sharing knowledge through engaging video content.",
    website: "https://alexjohnson.dev",
    twitter: "alexjohnson",
    instagram: "alexjohnson_creator",
    isPublic: true,
    createdAt: "2023-01-15T10:30:00Z",
    twoFactorEnabled: false,
    subscribers: 125000,
    totalViews: 2500000
  });

  // Mock settings data
  const [settings, setSettings] = useState({
    // Privacy settings
    showWatchHistory: false,
    showSubscriptions: true,
    showLikedVideos: false,
    allowDataCollection: true,
    personalizedAds: true,
    shareAnalytics: false,
    searchHistory: true,
    locationData: false,
    
    // Notification settings
    emailNotifications: true,
    pushNotifications: true,
    subscriptionUploads: true,
    subscriptionLive: true,
    commentReplies: true,
    videoLikes: false,
    channelMentions: true,
    systemUpdates: true,
    marketingEmails: false,
    weeklyDigest: true,
    emailFrequency: 'instant',
    quietHours: false,
    quietStart: '22:00',
    quietEnd: '08:00',
    
    // Playback settings
    autoplay: true,
    autoplayNext: true,
    defaultQuality: 'auto',
    subtitles: false,
    subtitleLanguage: 'en',
    darkMode: false,
    theaterMode: false,
    annotations: true,
    keyboardShortcuts: true,
    playbackSpeed: '1',
    volume: 80,
    muteOnStart: false
  });

  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
  }, []);

  const handleUpdateProfile = (profileData) => {
    setIsLoading(true);
    // Mock API call
    setTimeout(() => {
      console.log('Profile updated:', profileData);
      setIsLoading(false);
    }, 1000);
  };

  const handleUpdateSettings = (newSettings) => {
    setIsLoading(true);
    // Mock API call
    setTimeout(() => {
      setSettings(prev => ({ ...prev, ...newSettings }));
      console.log('Settings updated:', newSettings);
      setIsLoading(false);
    }, 1000);
  };

  const handleUpdateSecurity = (securityData) => {
    setIsLoading(true);
    // Mock API call
    setTimeout(() => {
      console.log('Security updated:', securityData);
      setIsLoading(false);
    }, 1000);
  };

  const renderActiveTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return (
          <ProfileSection
            user={user}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      case 'privacy':
        return (
          <PrivacySettings
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
          />
        );
      case 'notifications':
        return (
          <NotificationSettings
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
          />
        );
      case 'playback':
        return (
          <PlaybackSettings
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
          />
        );
      case 'security':
        return (
          <SecuritySettings
            user={user}
            onUpdateSecurity={handleUpdateSecurity}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} user={user} />
      
      <main className="pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center gap-4 mb-4">
              <Button
                variant="ghost"
                size="icon"
                iconName="ArrowLeft"
                onClick={() => navigate(-1)}
                className="lg:hidden"
              />
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-foreground">
                  Account Settings
                </h1>
                <p className="text-text-secondary mt-1">
                  Manage your account preferences and security settings
                </p>
              </div>
            </div>

            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-sm text-text-secondary">
              <button
                onClick={() => navigate('/')}
                className="hover:text-foreground transition-colors duration-200"
              >
                Home
              </button>
              <Icon name="ChevronRight" size={16} />
              <button
                onClick={() => navigate('/channel-profile')}
                className="hover:text-foreground transition-colors duration-200"
              >
                Profile
              </button>
              <Icon name="ChevronRight" size={16} />
              <span className="text-foreground">Settings</span>
            </nav>
          </div>

          {/* Settings Layout */}
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar Navigation */}
            <SettingsTabs
              activeTab={activeTab}
              onTabChange={setActiveTab}
            />

            {/* Main Content */}
            <div className="flex-1 min-w-0">
              {isLoading && (
                <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
                  <div className="bg-card rounded-lg border border-border p-6 flex items-center gap-3">
                    <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-foreground">Saving changes...</span>
                  </div>
                </div>
              )}
              
              {renderActiveTabContent()}
            </div>
          </div>

          {/* Quick Actions - Mobile */}
          <div className="lg:hidden mt-8 bg-card rounded-lg border border-border p-4">
            <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => navigate('/channel-profile')}
                iconName="User"
                iconPosition="left"
                className="justify-start"
              >
                View Profile
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate('/video-upload-management')}
                iconName="Upload"
                iconPosition="left"
                className="justify-start"
              >
                Upload Video
              </Button>
            </div>
          </div>

          {/* Help Section */}
          <div className="mt-8 bg-muted/30 rounded-lg p-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div className="flex items-start gap-3">
                <Icon name="HelpCircle" size={24} className="text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg font-medium text-foreground">Need Help?</h3>
                  <p className="text-text-secondary mt-1">
                    Visit our help center for guides and support articles about account settings.
                  </p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  variant="outline"
                  iconName="MessageCircle"
                  iconPosition="left"
                  onClick={() => console.log('Contact support')}
                >
                  Contact Support
                </Button>
                <Button
                  variant="outline"
                  iconName="BookOpen"
                  iconPosition="left"
                  onClick={() => console.log('Help center')}
                >
                  Help Center
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default UserProfileSettings;