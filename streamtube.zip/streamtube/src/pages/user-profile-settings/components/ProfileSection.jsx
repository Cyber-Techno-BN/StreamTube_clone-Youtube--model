import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ProfileSection = ({ user, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    bio: user?.bio || '',
    website: user?.website || '',
    twitter: user?.twitter || '',
    instagram: user?.instagram || '',
    isPublic: user?.isPublic || true
  });

  const handleInputChange = (e) => {
    const { name, value } = e?.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSave = () => {
    onUpdateProfile(formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      name: user?.name || '',
      bio: user?.bio || '',
      website: user?.website || '',
      twitter: user?.twitter || '',
      instagram: user?.instagram || '',
      isPublic: user?.isPublic || true
    });
    setIsEditing(false);
  };

  const handleAvatarUpload = () => {
    // Mock avatar upload functionality
    console.log('Avatar upload clicked');
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex flex-col lg:flex-row lg:items-start gap-6">
        {/* Avatar Section */}
        <div className="flex flex-col items-center lg:items-start">
          <div className="relative">
            <div className="w-24 h-24 lg:w-32 lg:h-32 rounded-full overflow-hidden bg-muted">
              <Image
                src={user?.avatar || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"}
                alt="Profile avatar"
                className="w-full h-full object-cover"
              />
            </div>
            <button
              onClick={handleAvatarUpload}
              className="absolute -bottom-2 -right-2 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:bg-primary/90 transition-colors duration-200"
            >
              <Icon name="Camera" size={16} />
            </button>
          </div>
          <p className="text-xs text-text-secondary mt-2 text-center lg:text-left">
            Click to upload new avatar
          </p>
        </div>

        {/* Profile Info */}
        <div className="flex-1 space-y-4">
          {!isEditing ? (
            <>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">{user?.name || 'User Name'}</h2>
                  <p className="text-text-secondary">{user?.email || 'user@example.com'}</p>
                  <p className="text-sm text-text-secondary">
                    Member since {new Date(user?.createdAt || '2023-01-15')?.toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'long' 
                    })}
                  </p>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setIsEditing(true)}
                  iconName="Edit"
                  iconPosition="left"
                >
                  Edit Profile
                </Button>
              </div>

              <div className="space-y-3">
                {formData?.bio && (
                  <div>
                    <h3 className="text-sm font-medium text-foreground mb-1">Bio</h3>
                    <p className="text-text-secondary">{formData?.bio}</p>
                  </div>
                )}

                {(formData?.website || formData?.twitter || formData?.instagram) && (
                  <div>
                    <h3 className="text-sm font-medium text-foreground mb-2">Social Links</h3>
                    <div className="flex flex-wrap gap-3">
                      {formData?.website && (
                        <a
                          href={formData?.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors duration-200"
                        >
                          <Icon name="Globe" size={16} />
                          Website
                        </a>
                      )}
                      {formData?.twitter && (
                        <a
                          href={`https://twitter.com/${formData?.twitter}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors duration-200"
                        >
                          <Icon name="Twitter" size={16} />
                          @{formData?.twitter}
                        </a>
                      )}
                      {formData?.instagram && (
                        <a
                          href={`https://instagram.com/${formData?.instagram}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors duration-200"
                        >
                          <Icon name="Instagram" size={16} />
                          @{formData?.instagram}
                        </a>
                      )}
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <Icon 
                    name={formData?.isPublic ? "Eye" : "EyeOff"} 
                    size={16} 
                    className="text-text-secondary" 
                  />
                  <span className="text-sm text-text-secondary">
                    Profile is {formData?.isPublic ? 'public' : 'private'}
                  </span>
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Input
                  label="Display Name"
                  name="name"
                  value={formData?.name}
                  onChange={handleInputChange}
                  placeholder="Enter your display name"
                  required
                />
                <Input
                  label="Website"
                  name="website"
                  type="url"
                  value={formData?.website}
                  onChange={handleInputChange}
                  placeholder="https://yourwebsite.com"
                />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Input
                  label="Twitter Username"
                  name="twitter"
                  value={formData?.twitter}
                  onChange={handleInputChange}
                  placeholder="username"
                />
                <Input
                  label="Instagram Username"
                  name="instagram"
                  value={formData?.instagram}
                  onChange={handleInputChange}
                  placeholder="username"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Bio
                </label>
                <textarea
                  name="bio"
                  value={formData?.bio}
                  onChange={handleInputChange}
                  placeholder="Tell us about yourself..."
                  rows={4}
                  className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground placeholder:text-text-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
                />
                <p className="text-xs text-text-secondary mt-1">
                  {formData?.bio?.length}/500 characters
                </p>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="isPublic"
                  checked={formData?.isPublic}
                  onChange={(e) => setFormData(prev => ({ ...prev, isPublic: e?.target?.checked }))}
                  className="w-4 h-4 text-primary bg-input border-border rounded focus:ring-ring focus:ring-2"
                />
                <label htmlFor="isPublic" className="text-sm text-foreground">
                  Make profile public
                </label>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Button
                  variant="default"
                  onClick={handleSave}
                  iconName="Check"
                  iconPosition="left"
                  className="sm:w-auto"
                >
                  Save Changes
                </Button>
                <Button
                  variant="outline"
                  onClick={handleCancel}
                  iconName="X"
                  iconPosition="left"
                  className="sm:w-auto"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfileSection;