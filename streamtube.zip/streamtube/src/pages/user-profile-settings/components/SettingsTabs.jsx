import React from 'react';
import Icon from '../../../components/AppIcon';

const SettingsTabs = ({ activeTab, onTabChange }) => {
  const tabs = [
    {
      id: 'profile',
      label: 'Profile Info',
      icon: 'User',
      description: 'Personal information and bio'
    },
    {
      id: 'privacy',
      label: 'Privacy',
      icon: 'Shield',
      description: 'Data and visibility settings'
    },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: 'Bell',
      description: 'Email and push preferences'
    },
    {
      id: 'playback',
      label: 'Playback',
      icon: 'Play',
      description: 'Video and audio preferences'
    },
    {
      id: 'security',
      label: 'Security',
      icon: 'Lock',
      description: 'Password and authentication'
    }
  ];

  return (
    <>
      {/* Desktop Sidebar Tabs */}
      <div className="hidden lg:block w-64 flex-shrink-0">
        <div className="bg-card rounded-lg border border-border p-4 sticky top-20">
          <h3 className="text-lg font-semibold text-foreground mb-4">Settings</h3>
          <nav className="space-y-2">
            {tabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => onTabChange(tab?.id)}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left transition-colors duration-200 ${
                  activeTab === tab?.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-text-secondary hover:text-foreground hover:bg-muted'
                }`}
              >
                <Icon 
                  name={tab?.icon} 
                  size={18} 
                  className={activeTab === tab?.id ? 'text-primary-foreground' : 'text-text-secondary'} 
                />
                <div className="flex-1 min-w-0">
                  <div className={`text-sm font-medium ${
                    activeTab === tab?.id ? 'text-primary-foreground' : 'text-foreground'
                  }`}>
                    {tab?.label}
                  </div>
                  <div className={`text-xs ${
                    activeTab === tab?.id ? 'text-primary-foreground/80' : 'text-text-secondary'
                  }`}>
                    {tab?.description}
                  </div>
                </div>
              </button>
            ))}
          </nav>
        </div>
      </div>
      {/* Mobile Tabs */}
      <div className="lg:hidden mb-6">
        <div className="bg-card rounded-lg border border-border p-2">
          <div className="flex overflow-x-auto scrollbar-hide gap-1">
            {tabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => onTabChange(tab?.id)}
                className={`flex-shrink-0 flex flex-col items-center gap-1 px-4 py-3 rounded-lg transition-colors duration-200 ${
                  activeTab === tab?.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-text-secondary hover:text-foreground hover:bg-muted'
                }`}
              >
                <Icon 
                  name={tab?.icon} 
                  size={18} 
                  className={activeTab === tab?.id ? 'text-primary-foreground' : 'text-text-secondary'} 
                />
                <span className={`text-xs font-medium whitespace-nowrap ${
                  activeTab === tab?.id ? 'text-primary-foreground' : 'text-foreground'
                }`}>
                  {tab?.label}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
      {/* Mobile Accordion Style (Alternative) */}
      <div className="lg:hidden mb-6 hidden">
        <div className="bg-card rounded-lg border border-border overflow-hidden">
          {tabs?.map((tab, index) => (
            <div key={tab?.id}>
              <button
                onClick={() => onTabChange(tab?.id)}
                className={`w-full flex items-center justify-between px-4 py-4 text-left transition-colors duration-200 ${
                  activeTab === tab?.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-muted'
                } ${index !== 0 ? 'border-t border-border' : ''}`}
              >
                <div className="flex items-center gap-3">
                  <Icon 
                    name={tab?.icon} 
                    size={18} 
                    className={activeTab === tab?.id ? 'text-primary-foreground' : 'text-text-secondary'} 
                  />
                  <div>
                    <div className={`text-sm font-medium ${
                      activeTab === tab?.id ? 'text-primary-foreground' : 'text-foreground'
                    }`}>
                      {tab?.label}
                    </div>
                    <div className={`text-xs ${
                      activeTab === tab?.id ? 'text-primary-foreground/80' : 'text-text-secondary'
                    }`}>
                      {tab?.description}
                    </div>
                  </div>
                </div>
                <Icon 
                  name={activeTab === tab?.id ? 'ChevronUp' : 'ChevronDown'} 
                  size={16} 
                  className={activeTab === tab?.id ? 'text-primary-foreground' : 'text-text-secondary'} 
                />
              </button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default SettingsTabs;