import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const SecuritySettings = ({ user, onUpdateSecurity }) => {
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [showTwoFactorSetup, setShowTwoFactorSetup] = useState(false);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(user?.twoFactorEnabled || false);
  const [backupCodes, setBackupCodes] = useState([]);
  const [showBackupCodes, setShowBackupCodes] = useState(false);

  const activeSessions = [
    {
      id: 1,
      device: "Chrome on Windows",
      location: "New York, NY",
      lastActive: "2 minutes ago",
      current: true,
      ip: "192.168.1.100"
    },
    {
      id: 2,
      device: "Safari on iPhone",
      location: "New York, NY",
      lastActive: "1 hour ago",
      current: false,
      ip: "192.168.1.101"
    },
    {
      id: 3,
      device: "Firefox on MacOS",
      location: "San Francisco, CA",
      lastActive: "3 days ago",
      current: false,
      ip: "10.0.0.50"
    }
  ];

  const handlePasswordChange = (e) => {
    const { name, value } = e?.target;
    setPasswordForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePasswordSubmit = (e) => {
    e?.preventDefault();
    if (passwordForm?.newPassword !== passwordForm?.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    // Mock password change
    console.log('Password changed successfully');
    setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    setShowPasswordForm(false);
  };

  const handleTwoFactorToggle = () => {
    if (!twoFactorEnabled) {
      setShowTwoFactorSetup(true);
    } else {
      setTwoFactorEnabled(false);
      setShowTwoFactorSetup(false);
    }
  };

  const handleTwoFactorSetup = () => {
    // Mock 2FA setup
    setTwoFactorEnabled(true);
    setShowTwoFactorSetup(false);
    // Generate mock backup codes
    const codes = Array.from({ length: 8 }, () => 
      Math.random()?.toString(36)?.substr(2, 8)?.toUpperCase()
    );
    setBackupCodes(codes);
    setShowBackupCodes(true);
  };

  const handleSignOutSession = (sessionId) => {
    console.log(`Signing out session ${sessionId}`);
  };

  const handleSignOutAllSessions = () => {
    console.log('Signing out all other sessions');
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Security Settings</h2>
          <p className="text-text-secondary mt-1">
            Manage your account security and access
          </p>
        </div>
      </div>
      <div className="space-y-8">
        {/* Password Section */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Icon name="Lock" size={20} className="text-primary" />
              <div>
                <h3 className="text-lg font-medium text-foreground">Password</h3>
                <p className="text-sm text-text-secondary">
                  Last changed on {new Date(2024, 7, 15)?.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => setShowPasswordForm(!showPasswordForm)}
              iconName="Edit"
              iconPosition="left"
            >
              Change Password
            </Button>
          </div>

          {showPasswordForm && (
            <form onSubmit={handlePasswordSubmit} className="space-y-4 mt-4 pt-4 border-t border-border">
              <Input
                label="Current Password"
                type="password"
                name="currentPassword"
                value={passwordForm?.currentPassword}
                onChange={handlePasswordChange}
                required
              />
              <Input
                label="New Password"
                type="password"
                name="newPassword"
                value={passwordForm?.newPassword}
                onChange={handlePasswordChange}
                description="Must be at least 8 characters long"
                required
              />
              <Input
                label="Confirm New Password"
                type="password"
                name="confirmPassword"
                value={passwordForm?.confirmPassword}
                onChange={handlePasswordChange}
                required
              />
              <div className="flex gap-3 pt-2">
                <Button
                  type="submit"
                  variant="default"
                  iconName="Check"
                  iconPosition="left"
                >
                  Update Password
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowPasswordForm(false)}
                  iconName="X"
                  iconPosition="left"
                >
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </div>

        {/* Two-Factor Authentication */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Icon name="Shield" size={20} className="text-primary" />
              <div>
                <h3 className="text-lg font-medium text-foreground">Two-Factor Authentication</h3>
                <p className="text-sm text-text-secondary">
                  {twoFactorEnabled ? 'Enabled' : 'Add an extra layer of security to your account'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {twoFactorEnabled && (
                <div className="flex items-center gap-2 text-success text-sm">
                  <Icon name="CheckCircle" size={16} />
                  <span>Enabled</span>
                </div>
              )}
              <Button
                variant={twoFactorEnabled ? "outline" : "default"}
                onClick={handleTwoFactorToggle}
                iconName={twoFactorEnabled ? "Settings" : "Plus"}
                iconPosition="left"
              >
                {twoFactorEnabled ? 'Manage' : 'Enable 2FA'}
              </Button>
            </div>
          </div>

          {showTwoFactorSetup && (
            <div className="mt-4 pt-4 border-t border-border">
              <div className="text-center space-y-4">
                <div className="w-32 h-32 bg-background border-2 border-dashed border-border rounded-lg mx-auto flex items-center justify-center">
                  <Icon name="QrCode" size={48} className="text-text-secondary" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground mb-2">Scan QR Code</h4>
                  <p className="text-sm text-text-secondary mb-4">
                    Use your authenticator app to scan this QR code
                  </p>
                  <p className="text-xs text-text-secondary font-mono bg-background px-3 py-2 rounded border">
                    Manual entry: JBSWY3DPEHPK3PXP
                  </p>
                </div>
                <div className="flex gap-3 justify-center">
                  <Button
                    variant="default"
                    onClick={handleTwoFactorSetup}
                    iconName="Check"
                    iconPosition="left"
                  >
                    Verify & Enable
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowTwoFactorSetup(false)}
                    iconName="X"
                    iconPosition="left"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}

          {showBackupCodes && (
            <div className="mt-4 pt-4 border-t border-border">
              <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Icon name="AlertTriangle" size={20} className="text-warning flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-foreground mb-2">Save Your Backup Codes</h4>
                    <p className="text-sm text-text-secondary mb-4">
                      Store these codes in a safe place. You can use them to access your account if you lose your authenticator device.
                    </p>
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      {backupCodes?.map((code, index) => (
                        <div key={index} className="bg-background px-3 py-2 rounded border font-mono text-sm">
                          {code}
                        </div>
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowBackupCodes(false)}
                      iconName="Check"
                      iconPosition="left"
                    >
                      I've Saved These Codes
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Active Sessions */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Icon name="Monitor" size={20} className="text-primary" />
              <div>
                <h3 className="text-lg font-medium text-foreground">Active Sessions</h3>
                <p className="text-sm text-text-secondary">
                  Manage devices that are signed into your account
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={handleSignOutAllSessions}
              iconName="LogOut"
              iconPosition="left"
            >
              Sign Out All
            </Button>
          </div>

          <div className="space-y-3">
            {activeSessions?.map((session) => (
              <div
                key={session?.id}
                className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors duration-200"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                    <Icon name="Monitor" size={18} className="text-text-secondary" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-medium text-foreground">
                        {session?.device}
                      </h4>
                      {session?.current && (
                        <span className="px-2 py-1 bg-success/10 text-success text-xs rounded-full">
                          Current
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-text-secondary">
                      {session?.location} • {session?.lastActive}
                    </p>
                    <p className="text-xs text-text-secondary">
                      IP: {session?.ip}
                    </p>
                  </div>
                </div>
                {!session?.current && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSignOutSession(session?.id)}
                    iconName="LogOut"
                    iconPosition="left"
                  >
                    Sign Out
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Login Alerts */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="Bell" size={20} className="text-primary" />
            <div>
              <h3 className="text-lg font-medium text-foreground">Login Alerts</h3>
              <p className="text-sm text-text-secondary">
                Get notified about suspicious login attempts
              </p>
            </div>
          </div>
          
          <div className="space-y-3">
            <Checkbox
              label="Email alerts for new device logins"
              description="Receive an email when your account is accessed from a new device"
              checked
              onChange={() => {}}
            />
            <Checkbox
              label="Email alerts for suspicious activity"
              description="Get notified about unusual login patterns or locations"
              checked
              onChange={() => {}}
            />
          </div>
        </div>
      </div>
      {/* Danger Zone */}
      <div className="mt-8 pt-6 border-t border-destructive/20">
        <div className="bg-destructive/5 border border-destructive/20 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Icon name="AlertTriangle" size={20} className="text-destructive flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="text-lg font-medium text-foreground mb-2">Danger Zone</h3>
              <p className="text-sm text-text-secondary mb-4">
                These actions are permanent and cannot be undone.
              </p>
              <Button
                variant="destructive"
                iconName="Trash2"
                iconPosition="left"
                onClick={() => console.log('Delete account clicked')}
              >
                Delete Account
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecuritySettings;