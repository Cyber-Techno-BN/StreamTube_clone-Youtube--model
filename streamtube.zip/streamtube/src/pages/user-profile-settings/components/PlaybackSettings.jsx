import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import { Checkbox } from '../../../components/ui/Checkbox';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const PlaybackSettings = ({ settings, onUpdateSettings }) => {
  const [playbackSettings, setPlaybackSettings] = useState({
    autoplay: settings?.autoplay || true,
    autoplayNext: settings?.autoplayNext || true,
    defaultQuality: settings?.defaultQuality || 'auto',
    subtitles: settings?.subtitles || false,
    subtitleLanguage: settings?.subtitleLanguage || 'en',
    darkMode: settings?.darkMode || false,
    theaterMode: settings?.theaterMode || false,
    annotations: settings?.annotations || true,
    keyboardShortcuts: settings?.keyboardShortcuts || true,
    playbackSpeed: settings?.playbackSpeed || '1',
    volume: settings?.volume || 80,
    muteOnStart: settings?.muteOnStart || false,
    ...settings
  });

  const [hasChanges, setHasChanges] = useState(false);

  const handleSettingChange = (key, value) => {
    setPlaybackSettings(prev => ({
      ...prev,
      [key]: value
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    onUpdateSettings(playbackSettings);
    setHasChanges(false);
  };

  const handleReset = () => {
    setPlaybackSettings({
      autoplay: settings?.autoplay || true,
      autoplayNext: settings?.autoplayNext || true,
      defaultQuality: settings?.defaultQuality || 'auto',
      subtitles: settings?.subtitles || false,
      subtitleLanguage: settings?.subtitleLanguage || 'en',
      darkMode: settings?.darkMode || false,
      theaterMode: settings?.theaterMode || false,
      annotations: settings?.annotations || true,
      keyboardShortcuts: settings?.keyboardShortcuts || true,
      playbackSpeed: settings?.playbackSpeed || '1',
      volume: settings?.volume || 80,
      muteOnStart: settings?.muteOnStart || false,
      ...settings
    });
    setHasChanges(false);
  };

  const qualityOptions = [
    { value: 'auto', label: 'Auto (Recommended)' },
    { value: '2160p', label: '2160p (4K)' },
    { value: '1440p', label: '1440p (2K)' },
    { value: '1080p', label: '1080p (HD)' },
    { value: '720p', label: '720p' },
    { value: '480p', label: '480p' },
    { value: '360p', label: '360p' },
    { value: '240p', label: '240p' }
  ];

  const languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Spanish' },
    { value: 'fr', label: 'French' },
    { value: 'de', label: 'German' },
    { value: 'it', label: 'Italian' },
    { value: 'pt', label: 'Portuguese' },
    { value: 'ru', label: 'Russian' },
    { value: 'ja', label: 'Japanese' },
    { value: 'ko', label: 'Korean' },
    { value: 'zh', label: 'Chinese' }
  ];

  const speedOptions = [
    { value: '0.25', label: '0.25x' },
    { value: '0.5', label: '0.5x' },
    { value: '0.75', label: '0.75x' },
    { value: '1', label: 'Normal' },
    { value: '1.25', label: '1.25x' },
    { value: '1.5', label: '1.5x' },
    { value: '1.75', label: '1.75x' },
    { value: '2', label: '2x' }
  ];

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Playback Settings</h2>
          <p className="text-text-secondary mt-1">
            Customize your video viewing experience
          </p>
        </div>
        {hasChanges && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleReset}
              iconName="RotateCcw"
              iconPosition="left"
            >
              Reset
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={handleSave}
              iconName="Check"
              iconPosition="left"
            >
              Save
            </Button>
          </div>
        )}
      </div>
      <div className="space-y-8">
        {/* Video Quality */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="Monitor" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Video Quality</h3>
          </div>
          <Select
            label="Default video quality"
            description="Choose the default quality for video playback"
            options={qualityOptions}
            value={playbackSettings?.defaultQuality}
            onChange={(value) => handleSettingChange('defaultQuality', value)}
            className="max-w-xs"
          />
        </div>

        {/* Autoplay Settings */}
        <div>
          <h3 className="text-lg font-medium text-foreground mb-4 flex items-center gap-2">
            <Icon name="Play" size={20} className="text-primary" />
            Autoplay
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-shrink-0 w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                <Icon name="Play" size={18} className="text-text-secondary" />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-foreground">
                      Autoplay Videos
                    </h4>
                    <p className="text-sm text-text-secondary mt-1">
                      Automatically start playing videos when you visit the page
                    </p>
                  </div>
                  
                  <div className="flex-shrink-0">
                    <Checkbox
                      checked={playbackSettings?.autoplay}
                      onChange={(e) => handleSettingChange('autoplay', e?.target?.checked)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-shrink-0 w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                <Icon name="SkipForward" size={18} className="text-text-secondary" />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-foreground">
                      Autoplay Next Video
                    </h4>
                    <p className="text-sm text-text-secondary mt-1">
                      Automatically play the next video when current video ends
                    </p>
                  </div>
                  
                  <div className="flex-shrink-0">
                    <Checkbox
                      checked={playbackSettings?.autoplayNext}
                      onChange={(e) => handleSettingChange('autoplayNext', e?.target?.checked)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Subtitles */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="Subtitles" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Subtitles</h3>
          </div>
          
          <div className="space-y-4">
            <Checkbox
              label="Enable subtitles by default"
              description="Automatically show subtitles when available"
              checked={playbackSettings?.subtitles}
              onChange={(e) => handleSettingChange('subtitles', e?.target?.checked)}
            />
            
            {playbackSettings?.subtitles && (
              <div className="ml-6">
                <Select
                  label="Preferred subtitle language"
                  options={languageOptions}
                  value={playbackSettings?.subtitleLanguage}
                  onChange={(value) => handleSettingChange('subtitleLanguage', value)}
                  className="max-w-xs"
                />
              </div>
            )}
          </div>
        </div>

        {/* Playback Speed */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="Gauge" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Playback Speed</h3>
          </div>
          <Select
            label="Default playback speed"
            description="Set your preferred video playback speed"
            options={speedOptions}
            value={playbackSettings?.playbackSpeed}
            onChange={(value) => handleSettingChange('playbackSpeed', value)}
            className="max-w-xs"
          />
        </div>

        {/* Volume Settings */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="Volume2" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Volume</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Default Volume: {playbackSettings?.volume}%
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={playbackSettings?.volume}
                onChange={(e) => handleSettingChange('volume', parseInt(e?.target?.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer slider"
              />
            </div>
            
            <Checkbox
              label="Mute videos on start"
              description="Start all videos with sound muted"
              checked={playbackSettings?.muteOnStart}
              onChange={(e) => handleSettingChange('muteOnStart', e?.target?.checked)}
            />
          </div>
        </div>

        {/* Display & Interface */}
        <div>
          <h3 className="text-lg font-medium text-foreground mb-4 flex items-center gap-2">
            <Icon name="Layout" size={20} className="text-primary" />
            Display & Interface
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-shrink-0 w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                <Icon name="Moon" size={18} className="text-text-secondary" />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-foreground">
                      Dark Mode
                    </h4>
                    <p className="text-sm text-text-secondary mt-1">
                      Use dark theme for better viewing in low light
                    </p>
                  </div>
                  
                  <div className="flex-shrink-0">
                    <Checkbox
                      checked={playbackSettings?.darkMode}
                      onChange={(e) => handleSettingChange('darkMode', e?.target?.checked)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-shrink-0 w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                <Icon name="Maximize" size={18} className="text-text-secondary" />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-foreground">
                      Theater Mode by Default
                    </h4>
                    <p className="text-sm text-text-secondary mt-1">
                      Start videos in theater mode for larger viewing
                    </p>
                  </div>
                  
                  <div className="flex-shrink-0">
                    <Checkbox
                      checked={playbackSettings?.theaterMode}
                      onChange={(e) => handleSettingChange('theaterMode', e?.target?.checked)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-shrink-0 w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                <Icon name="MessageSquare" size={18} className="text-text-secondary" />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-foreground">
                      Show Annotations
                    </h4>
                    <p className="text-sm text-text-secondary mt-1">
                      Display video annotations and interactive elements
                    </p>
                  </div>
                  
                  <div className="flex-shrink-0">
                    <Checkbox
                      checked={playbackSettings?.annotations}
                      onChange={(e) => handleSettingChange('annotations', e?.target?.checked)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-shrink-0 w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                <Icon name="Keyboard" size={18} className="text-text-secondary" />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-foreground">
                      Keyboard Shortcuts
                    </h4>
                    <p className="text-sm text-text-secondary mt-1">
                      Enable keyboard shortcuts for video control (Space, Arrow keys, etc.)
                    </p>
                  </div>
                  
                  <div className="flex-shrink-0">
                    <Checkbox
                      checked={playbackSettings?.keyboardShortcuts}
                      onChange={(e) => handleSettingChange('keyboardShortcuts', e?.target?.checked)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlaybackSettings;