import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import { Checkbox } from '../../../components/ui/Checkbox';
import Button from '../../../components/ui/Button';

const PrivacySettings = ({ settings, onUpdateSettings }) => {
  const [privacySettings, setPrivacySettings] = useState({
    showWatchHistory: settings?.showWatchHistory || false,
    showSubscriptions: settings?.showSubscriptions || true,
    showLikedVideos: settings?.showLikedVideos || false,
    allowDataCollection: settings?.allowDataCollection || true,
    personalizedAds: settings?.personalizedAds || true,
    shareAnalytics: settings?.shareAnalytics || false,
    searchHistory: settings?.searchHistory || true,
    locationData: settings?.locationData || false,
    ...settings
  });

  const [hasChanges, setHasChanges] = useState(false);

  const handleSettingChange = (key, value) => {
    setPrivacySettings(prev => ({
      ...prev,
      [key]: value
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    onUpdateSettings(privacySettings);
    setHasChanges(false);
  };

  const handleReset = () => {
    setPrivacySettings({
      showWatchHistory: settings?.showWatchHistory || false,
      showSubscriptions: settings?.showSubscriptions || true,
      showLikedVideos: settings?.showLikedVideos || false,
      allowDataCollection: settings?.allowDataCollection || true,
      personalizedAds: settings?.personalizedAds || true,
      shareAnalytics: settings?.shareAnalytics || false,
      searchHistory: settings?.searchHistory || true,
      locationData: settings?.locationData || false,
      ...settings
    });
    setHasChanges(false);
  };

  const privacyOptions = [
    {
      category: "Profile Visibility",
      options: [
        {
          key: "showWatchHistory",
          title: "Show Watch History",
          description: "Allow others to see videos you\'ve watched on your public profile",
          icon: "Eye"
        },
        {
          key: "showSubscriptions",
          title: "Show Subscriptions",
          description: "Display your channel subscriptions publicly",
          icon: "Users"
        },
        {
          key: "showLikedVideos",
          title: "Show Liked Videos",
          description: "Make your liked videos visible to others",
          icon: "Heart"
        }
      ]
    },
    {
      category: "Data & Analytics",
      options: [
        {
          key: "allowDataCollection",
          title: "Allow Data Collection",
          description: "Help improve our service by sharing usage data",
          icon: "BarChart3"
        },
        {
          key: "personalizedAds",
          title: "Personalized Advertisements",
          description: "Show ads based on your interests and activity",
          icon: "Target"
        },
        {
          key: "shareAnalytics",
          title: "Share Analytics with Creators",
          description: "Allow creators to see anonymous viewing statistics",
          icon: "TrendingUp"
        }
      ]
    },
    {
      category: "Activity Tracking",
      options: [
        {
          key: "searchHistory",
          title: "Save Search History",
          description: "Store your searches to improve recommendations",
          icon: "Search"
        },
        {
          key: "locationData",
          title: "Use Location Data",
          description: "Use your location for relevant content and features",
          icon: "MapPin"
        }
      ]
    }
  ];

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Privacy Settings</h2>
          <p className="text-text-secondary mt-1">
            Control how your data is used and what others can see
          </p>
        </div>
        {hasChanges && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleReset}
              iconName="RotateCcw"
              iconPosition="left"
            >
              Reset
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={handleSave}
              iconName="Check"
              iconPosition="left"
            >
              Save
            </Button>
          </div>
        )}
      </div>
      <div className="space-y-8">
        {privacyOptions?.map((category, categoryIndex) => (
          <div key={categoryIndex}>
            <h3 className="text-lg font-medium text-foreground mb-4 flex items-center gap-2">
              <div className="w-1 h-6 bg-primary rounded-full"></div>
              {category?.category}
            </h3>
            
            <div className="space-y-4">
              {category?.options?.map((option, optionIndex) => (
                <div
                  key={optionIndex}
                  className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                >
                  <div className="flex-shrink-0 w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                    <Icon name={option?.icon} size={18} className="text-text-secondary" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-foreground">
                          {option?.title}
                        </h4>
                        <p className="text-sm text-text-secondary mt-1">
                          {option?.description}
                        </p>
                      </div>
                      
                      <div className="flex-shrink-0">
                        <Checkbox
                          checked={privacySettings?.[option?.key]}
                          onChange={(e) => handleSettingChange(option?.key, e?.target?.checked)}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      {/* Data Export Section */}
      <div className="mt-8 pt-6 border-t border-border">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h3 className="text-lg font-medium text-foreground">Data Export</h3>
            <p className="text-text-secondary mt-1">
              Download a copy of your data for your records
            </p>
          </div>
          <Button
            variant="outline"
            iconName="Download"
            iconPosition="left"
            onClick={() => console.log('Export data clicked')}
          >
            Export My Data
          </Button>
        </div>
      </div>
      {/* Privacy Policy Link */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center gap-2 text-sm text-text-secondary">
          <Icon name="Shield" size={16} />
          <span>
            Learn more about our{' '}
            <a href="#" className="text-primary hover:text-primary/80 transition-colors duration-200">
              Privacy Policy
            </a>{' '}
            and{' '}
            <a href="#" className="text-primary hover:text-primary/80 transition-colors duration-200">
              Terms of Service
            </a>
          </span>
        </div>
      </div>
    </div>
  );
};

export default PrivacySettings;