import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import { Checkbox } from '../../../components/ui/Checkbox';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const NotificationSettings = ({ settings, onUpdateSettings }) => {
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: settings?.emailNotifications || true,
    pushNotifications: settings?.pushNotifications || true,
    subscriptionUploads: settings?.subscriptionUploads || true,
    subscriptionLive: settings?.subscriptionLive || true,
    commentReplies: settings?.commentReplies || true,
    videoLikes: settings?.videoLikes || false,
    channelMentions: settings?.channelMentions || true,
    systemUpdates: settings?.systemUpdates || true,
    marketingEmails: settings?.marketingEmails || false,
    weeklyDigest: settings?.weeklyDigest || true,
    emailFrequency: settings?.emailFrequency || 'instant',
    quietHours: settings?.quietHours || false,
    quietStart: settings?.quietStart || '22:00',
    quietEnd: settings?.quietEnd || '08:00',
    ...settings
  });

  const [hasChanges, setHasChanges] = useState(false);

  const handleSettingChange = (key, value) => {
    setNotificationSettings(prev => ({
      ...prev,
      [key]: value
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    onUpdateSettings(notificationSettings);
    setHasChanges(false);
  };

  const handleReset = () => {
    setNotificationSettings({
      emailNotifications: settings?.emailNotifications || true,
      pushNotifications: settings?.pushNotifications || true,
      subscriptionUploads: settings?.subscriptionUploads || true,
      subscriptionLive: settings?.subscriptionLive || true,
      commentReplies: settings?.commentReplies || true,
      videoLikes: settings?.videoLikes || false,
      channelMentions: settings?.channelMentions || true,
      systemUpdates: settings?.systemUpdates || true,
      marketingEmails: settings?.marketingEmails || false,
      weeklyDigest: settings?.weeklyDigest || true,
      emailFrequency: settings?.emailFrequency || 'instant',
      quietHours: settings?.quietHours || false,
      quietStart: settings?.quietStart || '22:00',
      quietEnd: settings?.quietEnd || '08:00',
      ...settings
    });
    setHasChanges(false);
  };

  const frequencyOptions = [
    { value: 'instant', label: 'Instant' },
    { value: 'hourly', label: 'Hourly digest' },
    { value: 'daily', label: 'Daily digest' },
    { value: 'weekly', label: 'Weekly digest' },
    { value: 'never', label: 'Never' }
  ];

  const notificationCategories = [
    {
      title: "General Notifications",
      icon: "Bell",
      options: [
        {
          key: "emailNotifications",
          title: "Email Notifications",
          description: "Receive notifications via email",
          icon: "Mail"
        },
        {
          key: "pushNotifications",
          title: "Push Notifications",
          description: "Receive browser push notifications",
          icon: "Smartphone"
        }
      ]
    },
    {
      title: "Subscription Activity",
      icon: "Users",
      options: [
        {
          key: "subscriptionUploads",
          title: "New Video Uploads",
          description: "When channels you subscribe to upload new videos",
          icon: "Upload"
        },
        {
          key: "subscriptionLive",
          title: "Live Streams",
          description: "When subscribed channels go live",
          icon: "Radio"
        }
      ]
    },
    {
      title: "Engagement",
      icon: "MessageCircle",
      options: [
        {
          key: "commentReplies",
          title: "Comment Replies",
          description: "When someone replies to your comments",
          icon: "Reply"
        },
        {
          key: "videoLikes",
          title: "Video Likes",
          description: "When someone likes your videos",
          icon: "Heart"
        },
        {
          key: "channelMentions",
          title: "Channel Mentions",
          description: "When your channel is mentioned",
          icon: "AtSign"
        }
      ]
    },
    {
      title: "Platform Updates",
      icon: "Settings",
      options: [
        {
          key: "systemUpdates",
          title: "System Updates",
          description: "Important platform updates and announcements",
          icon: "Info"
        },
        {
          key: "marketingEmails",
          title: "Marketing Emails",
          description: "Promotional content and feature highlights",
          icon: "Tag"
        },
        {
          key: "weeklyDigest",
          title: "Weekly Digest",
          description: "Summary of your activity and recommendations",
          icon: "Calendar"
        }
      ]
    }
  ];

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Notification Settings</h2>
          <p className="text-text-secondary mt-1">
            Manage how and when you receive notifications
          </p>
        </div>
        {hasChanges && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleReset}
              iconName="RotateCcw"
              iconPosition="left"
            >
              Reset
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={handleSave}
              iconName="Check"
              iconPosition="left"
            >
              Save
            </Button>
          </div>
        )}
      </div>
      <div className="space-y-8">
        {/* Email Frequency Setting */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="Clock" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Email Frequency</h3>
          </div>
          <Select
            label="How often would you like to receive email notifications?"
            options={frequencyOptions}
            value={notificationSettings?.emailFrequency}
            onChange={(value) => handleSettingChange('emailFrequency', value)}
            className="max-w-xs"
          />
        </div>

        {/* Notification Categories */}
        {notificationCategories?.map((category, categoryIndex) => (
          <div key={categoryIndex}>
            <h3 className="text-lg font-medium text-foreground mb-4 flex items-center gap-2">
              <Icon name={category?.icon} size={20} className="text-primary" />
              {category?.title}
            </h3>
            
            <div className="space-y-3">
              {category?.options?.map((option, optionIndex) => (
                <div
                  key={optionIndex}
                  className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors duration-200"
                >
                  <div className="flex-shrink-0 w-10 h-10 bg-background border border-border rounded-lg flex items-center justify-center">
                    <Icon name={option?.icon} size={18} className="text-text-secondary" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-foreground">
                          {option?.title}
                        </h4>
                        <p className="text-sm text-text-secondary mt-1">
                          {option?.description}
                        </p>
                      </div>
                      
                      <div className="flex-shrink-0">
                        <Checkbox
                          checked={notificationSettings?.[option?.key]}
                          onChange={(e) => handleSettingChange(option?.key, e?.target?.checked)}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Quiet Hours */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="Moon" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Quiet Hours</h3>
          </div>
          
          <div className="space-y-4">
            <Checkbox
              label="Enable quiet hours"
              description="Pause notifications during specified hours"
              checked={notificationSettings?.quietHours}
              onChange={(e) => handleSettingChange('quietHours', e?.target?.checked)}
            />
            
            {notificationSettings?.quietHours && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 ml-6">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={notificationSettings?.quietStart}
                    onChange={(e) => handleSettingChange('quietStart', e?.target?.value)}
                    className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={notificationSettings?.quietEnd}
                    onChange={(e) => handleSettingChange('quietEnd', e?.target?.value)}
                    className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Test Notification */}
      <div className="mt-8 pt-6 border-t border-border">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h3 className="text-lg font-medium text-foreground">Test Notifications</h3>
            <p className="text-text-secondary mt-1">
              Send a test notification to verify your settings
            </p>
          </div>
          <Button
            variant="outline"
            iconName="Send"
            iconPosition="left"
            onClick={() => console.log('Test notification sent')}
          >
            Send Test
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotificationSettings;