import React, { useState } from 'react';
import MainHeader from '../../components/ui/MainHeader';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const Trending = () => {
  const [selectedTab, setSelectedTab] = useState('now');

  // Mock user data
  const mockUser = {
    name: "Alex Johnson",
    email: "alex.johnson@example.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"
  };

  const tabs = [
    { id: 'now', label: 'Now', icon: 'TrendingUp' },
    { id: 'music', label: 'Music', icon: 'Music' },
    { id: 'gaming', label: 'Gaming', icon: 'Gamepad2' },
    { id: 'movies', label: 'Movies', icon: 'Film' },
  ];

  // Mock trending videos data
  const mockTrendingVideos = [
    {
      id: "t1",
      title: "This Video Broke The Internet - 100M Views in 24 Hours!",
      thumbnail: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=400&h=225&fit=crop",
      duration: 1247,
      views: 100000000,
      publishedAt: "2024-01-16T08:00:00Z",
      channel: {
        name: "Viral Central",
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "50M"
      },
      trending: {
        position: 1,
        category: 'now'
      }
    },
    {
      id: "t2",
      title: "New Chart-Topping Hit - Music Video Premiere",
      thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=225&fit=crop",
      duration: 234,
      views: 25000000,
      publishedAt: "2024-01-15T12:00:00Z",
      channel: {
        name: "Pop Music Official",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "15M"
      },
      trending: {
        position: 2,
        category: 'music'
      }
    },
    {
      id: "t3",
      title: "World Record Gaming Achievement - Live Reaction",
      thumbnail: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400&h=225&fit=crop",
      duration: 1834,
      views: 15000000,
      publishedAt: "2024-01-14T20:30:00Z",
      channel: {
        name: "Pro Gamer Elite",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "8M"
      },
      trending: {
        position: 3,
        category: 'gaming'
      }
    },
    {
      id: "t4",
      title: "Exclusive Movie Trailer - Most Anticipated Film of 2024",
      thumbnail: "https://images.unsplash.com/photo-1489599843360-2853b5a028b2?w=400&h=225&fit=crop",
      duration: 156,
      views: 45000000,
      publishedAt: "2024-01-13T16:00:00Z",
      channel: {
        name: "Hollywood Studios",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        isVerified: true,
        subscribers: "25M"
      },
      trending: {
        position: 4,
        category: 'movies'
      }
    }
  ];

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${remainingSeconds?.toString()?.padStart(2, '0')}`;
  };

  const formatViews = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000)?.toFixed(1)}M views`;
    }
    if (views >= 1000) {
      return `${(views / 1000)?.toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const formatTimeAgo = (publishedAt) => {
    const now = new Date();
    const published = new Date(publishedAt);
    const diffInHours = Math.floor((now - published) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  const filteredVideos = selectedTab === 'now' 
    ? mockTrendingVideos 
    : mockTrendingVideos?.filter(video => video?.trending?.category === selectedTab);

  const handleVideoClick = (videoId) => {
    window.location.href = `/video-player?v=${videoId}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} user={mockUser} />
      
      <main className="pt-14 md:pt-16">
        {/* Header */}
        <div className="border-b border-border">
          <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
            <div className="flex items-center gap-3 mb-6">
              <Icon name="TrendingUp" size={32} className="text-primary" />
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">Trending</h1>
            </div>

            {/* Trending Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
              {tabs?.map((tab) => (
                <Button
                  key={tab?.id}
                  variant={selectedTab === tab?.id ? "primary" : "ghost"}
                  onClick={() => setSelectedTab(tab?.id)}
                  className="whitespace-nowrap flex-shrink-0"
                >
                  <Icon name={tab?.icon} size={16} className="mr-2" />
                  {tab?.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Trending Videos */}
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
          <div className="space-y-4">
            {filteredVideos?.map((video) => (
              <div
                key={video?.id}
                className="flex gap-4 p-4 rounded-lg hover:bg-muted cursor-pointer transition-colors duration-200"
                onClick={() => handleVideoClick(video?.id)}
              >
                {/* Trending Position */}
                <div className="flex-shrink-0 text-2xl font-bold text-primary min-w-[40px]">
                  #{video?.trending?.position}
                </div>

                {/* Thumbnail */}
                <div className="relative aspect-video w-48 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
                  <img
                    src={video?.thumbnail}
                    alt={video?.title}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Duration */}
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
                    {formatDuration(video?.duration)}
                  </div>
                </div>

                {/* Video Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-foreground line-clamp-2 mb-2">
                    {video?.title}
                  </h3>
                  
                  <div className="flex items-center gap-2 mb-2">
                    <img
                      src={video?.channel?.avatar}
                      alt={video?.channel?.name}
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="text-sm text-text-secondary">
                      {video?.channel?.name}
                    </span>
                    {video?.channel?.isVerified && (
                      <Icon name="CheckCircle" size={12} className="text-primary" />
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm text-text-secondary">
                    <span>{formatViews(video?.views)}</span>
                    <span>•</span>
                    <span>{formatTimeAgo(video?.publishedAt)}</span>
                  </div>
                </div>

                {/* Trending Icon */}
                <div className="flex-shrink-0 self-center">
                  <Icon name="TrendingUp" size={20} className="text-primary" />
                </div>
              </div>
            ))}
          </div>

          {/* No Results Message */}
          {filteredVideos?.length === 0 && (
            <div className="text-center py-12">
              <Icon name="TrendingUp" size={48} className="mx-auto text-text-secondary mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                No trending videos
              </h3>
              <p className="text-text-secondary">
                Check back later for trending content in this category.
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Trending;