import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import MainHeader from '../../components/ui/MainHeader';
import SearchFilters from './components/SearchFilters';
import SearchResultCard from './components/SearchResultCard';
import ActiveFilters from './components/ActiveFilters';
import SearchSuggestions from './components/SearchSuggestions';
import ViewModeToggle from './components/ViewModeToggle';
import LoadingSpinner from './components/LoadingSpinner';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const SearchResults = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [query, setQuery] = useState(searchParams?.get('q') || '');
  const [results, setResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState('list');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filters, setFilters] = useState({
    uploadDate: 'any',
    duration: 'any',
    type: 'all',
    sortBy: 'relevance',
    hasSubtitles: false,
    isHD: false,
    isLive: false
  });

  const mockResults = [
    {
      id: '1',
      type: 'video',
      title: 'Complete React Tutorial for Beginners - Learn React in 2024',
      description: 'Learn React from scratch with this comprehensive tutorial. We cover components, hooks, state management, and more. Perfect for beginners who want to master React development.',
      thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
      channelName: 'CodeMaster Pro',
      channelId: 'codemaster-pro',
      channelAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
      isChannelVerified: true,
      views: 1250000,
      uploadDate: new Date('2024-01-15'),
      duration: 3600,
      isLive: false
    },
    {
      id: '2',
      type: 'video',
      title: 'JavaScript ES6+ Features You Must Know',
      description: 'Explore the latest JavaScript features including arrow functions, destructuring, async/await, and more. Essential knowledge for modern web development.',
      thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop',
      channelName: 'WebDev Academy',
      channelId: 'webdev-academy',
      channelAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
      isChannelVerified: false,
      views: 850000,
      uploadDate: new Date('2024-02-10'),
      duration: 2400,
      isLive: false
    },
    {
      id: '3',
      type: 'channel',
      name: 'React Developers Hub',
      description: 'Your go-to channel for React tutorials, tips, and best practices. Join our community of developers learning React together.',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop&crop=face',
      subscriberCount: '2.5M',
      isVerified: true
    },
    {
      id: '4',
      type: 'playlist',
      title: 'Full Stack Web Development Course',
      description: 'Complete playlist covering HTML, CSS, JavaScript, React, Node.js, and database integration. Everything you need to become a full stack developer.',
      thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=225&fit=crop',
      channelName: 'Tech Education',
      channelId: 'tech-education',
      videoCount: 45
    },
    {
      id: '5',
      type: 'video',
      title: 'Building a Modern React App with Hooks and Context',
      description: 'Step-by-step guide to building a complete React application using modern patterns like hooks, context API, and functional components.',
      thumbnail: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&h=225&fit=crop',
      channelName: 'Modern Web Dev',
      channelId: 'modern-web-dev',
      channelAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face',
      isChannelVerified: true,
      views: 420000,
      uploadDate: new Date('2024-03-05'),
      duration: 4200,
      isLive: false
    },
    {
      id: '6',
      type: 'video',
      title: 'Live Coding: React Performance Optimization',
      description: 'Join us for a live coding session where we optimize a React application for better performance using memoization, lazy loading, and more.',
      thumbnail: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=225&fit=crop',
      channelName: 'Live Code Sessions',
      channelId: 'live-code-sessions',
      channelAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face',
      isChannelVerified: false,
      views: 15000,
      uploadDate: new Date('2024-08-20'),
      duration: 7200,
      isLive: true
    }
  ];

  const searchResults = useCallback(() => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      let filteredResults = [...mockResults];
      
      // Apply filters
      if (filters?.type !== 'all') {
        filteredResults = filteredResults?.filter(result => result?.type === filters?.type);
      }
      
      if (filters?.isLive) {
        filteredResults = filteredResults?.filter(result => result?.isLive);
      }
      
      if (filters?.isHD) {
        filteredResults = filteredResults?.filter(result => result?.type === 'video');
      }
      
      // Apply sorting
      if (filters?.sortBy === 'date') {
        filteredResults?.sort((a, b) => new Date(b.uploadDate) - new Date(a.uploadDate));
      } else if (filters?.sortBy === 'views') {
        filteredResults?.sort((a, b) => (b?.views || 0) - (a?.views || 0));
      }
      
      if (page === 1) {
        setResults(filteredResults);
      } else {
        setResults(prev => [...prev, ...filteredResults?.slice(6)]);
      }
      
      setHasMore(filteredResults?.length > 6);
      setIsLoading(false);
    }, 500);
  }, [filters, page]);

  useEffect(() => {
    if (query) {
      setPage(1);
      searchResults();
    }
  }, [query, filters]);

  useEffect(() => {
    const queryParam = searchParams?.get('q');
    if (queryParam) {
      setQuery(queryParam);
    }
  }, [searchParams]);

  const handleSearch = (searchQuery = query) => {
    if (searchQuery?.trim()) {
      setQuery(searchQuery);
      setSearchParams({ q: searchQuery });
      setShowSuggestions(false);
    }
  };

  const handleLoadMore = () => {
    setPage(prev => prev + 1);
  };

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
    setPage(1);
  };

  const handleRemoveFilter = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleClearAllFilters = () => {
    setFilters({
      uploadDate: 'any',
      duration: 'any',
      type: 'all',
      sortBy: 'relevance',
      hasSubtitles: false,
      isHD: false,
      isLive: false
    });
  };

  const handleSuggestionClick = (suggestion) => {
    handleSearch(suggestion);
  };

  const resultCount = results?.length;
  const hasActiveFilters = Object.values(filters)?.some((value, index) => {
    const defaults = ['any', 'any', 'all', 'relevance', false, false, false];
    return value !== defaults?.[index];
  });

  return (
    <div className="min-h-screen bg-background">
      <MainHeader isAuthenticated={true} />
      <div className="pt-16 flex">
        {/* Filters Sidebar */}
        <SearchFilters
          isOpen={showFilters}
          onClose={() => setShowFilters(false)}
          filters={filters}
          onFiltersChange={handleFiltersChange}
        />

        {/* Main Content */}
        <div className="flex-1 lg:ml-0">
          {/* Search Header */}
          <div className="sticky top-16 bg-background border-b border-border z-30">
            <div className="p-4">
              <div className="flex items-center space-x-4 mb-4">
                {/* Mobile Filter Toggle */}
                <Button
                  variant="outline"
                  size="icon"
                  iconName="Filter"
                  onClick={() => setShowFilters(true)}
                  className="lg:hidden"
                />

                {/* Search Input */}
                <div className="relative flex-1 max-w-2xl">
                  <Input
                    type="search"
                    value={query}
                    onChange={(e) => setQuery(e?.target?.value)}
                    onKeyDown={(e) => e?.key === 'Enter' && handleSearch()}
                    onFocus={() => setShowSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    placeholder="Search videos, channels, and more..."
                    className="pr-12"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    iconName="Search"
                    onClick={() => handleSearch()}
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8"
                  />
                  
                  <SearchSuggestions
                    query={query}
                    onSuggestionClick={handleSuggestionClick}
                    isVisible={showSuggestions}
                  />
                </div>

                {/* View Mode Toggle */}
                <ViewModeToggle
                  viewMode={viewMode}
                  onViewModeChange={setViewMode}
                />
              </div>

              {/* Results Info */}
              <div className="flex items-center justify-between text-sm text-text-secondary">
                <span>
                  {query && `About ${resultCount?.toLocaleString()} results for "${query}"`}
                </span>
                {hasActiveFilters && (
                  <span className="flex items-center space-x-1">
                    <Icon name="Filter" size={14} />
                    <span>Filtered</span>
                  </span>
                )}
              </div>
            </div>

            {/* Active Filters */}
            <ActiveFilters
              filters={filters}
              onRemoveFilter={handleRemoveFilter}
              onClearAll={handleClearAllFilters}
            />
          </div>

          {/* Results Content */}
          <div className="p-4">
            {isLoading && page === 1 ? (
              <LoadingSpinner size="lg" />
            ) : results?.length === 0 ? (
              <div className="text-center py-12">
                <Icon name="Search" size={48} className="mx-auto text-text-secondary mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">No results found</h3>
                <p className="text-text-secondary mb-4">
                  Try different keywords or remove search filters
                </p>
                <Button
                  variant="outline"
                  onClick={handleClearAllFilters}
                >
                  Clear filters
                </Button>
              </div>
            ) : (
              <>
                {/* Results Grid/List */}
                <div className={
                  viewMode === 'grid' ?'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4' :'space-y-4'
                }>
                  {results?.map((result) => (
                    <SearchResultCard
                      key={result?.id}
                      result={result}
                      viewMode={viewMode}
                    />
                  ))}
                </div>

                {/* Load More */}
                {hasMore && (
                  <div className="text-center mt-8">
                    {isLoading ? (
                      <LoadingSpinner />
                    ) : (
                      <Button
                        variant="outline"
                        onClick={handleLoadMore}
                        iconName="ChevronDown"
                        iconPosition="right"
                      >
                        Load more results
                      </Button>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchResults;