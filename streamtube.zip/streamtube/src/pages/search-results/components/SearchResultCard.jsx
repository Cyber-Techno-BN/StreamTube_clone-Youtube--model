import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';


const SearchResultCard = ({ result, viewMode = 'list' }) => {
  const navigate = useNavigate();

  const formatViewCount = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000)?.toFixed(1)}M views`;
    } else if (views >= 1000) {
      return `${(views / 1000)?.toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${secs?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const getTimeAgo = (date) => {
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    if (diffInSeconds < 31536000) return `${Math.floor(diffInSeconds / 2592000)} months ago`;
    return `${Math.floor(diffInSeconds / 31536000)} years ago`;
  };

  const handleResultClick = () => {
    if (result?.type === 'video') {
      navigate(`/video-player?v=${result?.id}`);
    } else if (result?.type === 'channel') {
      navigate(`/channel-profile?c=${result?.id}`);
    }
  };

  const handleChannelClick = (e) => {
    e?.stopPropagation();
    navigate(`/channel-profile?c=${result?.channelId}`);
  };

  if (result?.type === 'channel') {
    return (
      <div 
        className="flex items-center space-x-4 p-4 hover:bg-muted rounded-lg cursor-pointer transition-colors duration-200"
        onClick={handleResultClick}
      >
        <div className="w-16 h-16 rounded-full overflow-hidden bg-muted flex-shrink-0">
          <Image
            src={result?.avatar}
            alt={result?.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <h3 className="text-lg font-semibold text-foreground truncate">{result?.name}</h3>
            {result?.isVerified && (
              <Icon name="CheckCircle" size={16} className="text-primary flex-shrink-0" />
            )}
          </div>
          <p className="text-sm text-text-secondary">{result?.subscriberCount} subscribers</p>
          {result?.description && (
            <p className="text-sm text-text-secondary mt-1 line-clamp-2">{result?.description}</p>
          )}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={(e) => {
            e?.stopPropagation();
            // Handle subscribe logic
          }}
        >
          Subscribe
        </Button>
      </div>
    );
  }

  if (result?.type === 'playlist') {
    return (
      <div 
        className="flex space-x-4 p-4 hover:bg-muted rounded-lg cursor-pointer transition-colors duration-200"
        onClick={handleResultClick}
      >
        <div className="relative w-48 h-28 bg-muted rounded-lg overflow-hidden flex-shrink-0">
          <Image
            src={result?.thumbnail}
            alt={result?.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
            <Icon name="Play" size={24} className="text-white" />
          </div>
          <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
            {result?.videoCount} videos
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-semibold text-foreground line-clamp-2 mb-2">{result?.title}</h3>
          <button
            onClick={handleChannelClick}
            className="text-sm text-text-secondary hover:text-foreground transition-colors duration-200"
          >
            {result?.channelName}
          </button>
          {result?.description && (
            <p className="text-sm text-text-secondary mt-2 line-clamp-2">{result?.description}</p>
          )}
        </div>
      </div>
    );
  }

  // Video result
  if (viewMode === 'grid') {
    return (
      <div 
        className="bg-background rounded-lg overflow-hidden hover:bg-muted transition-colors duration-200 cursor-pointer"
        onClick={handleResultClick}
      >
        <div className="relative aspect-video bg-muted">
          <Image
            src={result?.thumbnail}
            alt={result?.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
            {formatDuration(result?.duration)}
          </div>
        </div>
        <div className="p-3">
          <h3 className="text-sm font-semibold text-foreground line-clamp-2 mb-2">{result?.title}</h3>
          <button
            onClick={handleChannelClick}
            className="text-xs text-text-secondary hover:text-foreground transition-colors duration-200 block mb-1"
          >
            {result?.channelName}
          </button>
          <div className="flex items-center space-x-2 text-xs text-text-secondary">
            <span>{formatViewCount(result?.views)}</span>
            <span>•</span>
            <span>{getTimeAgo(result?.uploadDate)}</span>
          </div>
        </div>
      </div>
    );
  }

  // List view (default)
  return (
    <div 
      className="flex space-x-4 p-4 hover:bg-muted rounded-lg cursor-pointer transition-colors duration-200"
      onClick={handleResultClick}
    >
      <div className="relative w-48 h-28 bg-muted rounded-lg overflow-hidden flex-shrink-0">
        <Image
          src={result?.thumbnail}
          alt={result?.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
          {formatDuration(result?.duration)}
        </div>
        {result?.isLive && (
          <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded">
            LIVE
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="text-lg font-semibold text-foreground line-clamp-2 mb-2">{result?.title}</h3>
        <div className="flex items-center space-x-2 text-sm text-text-secondary mb-2">
          <span>{formatViewCount(result?.views)}</span>
          <span>•</span>
          <span>{getTimeAgo(result?.uploadDate)}</span>
        </div>
        <button
          onClick={handleChannelClick}
          className="text-sm text-text-secondary hover:text-foreground transition-colors duration-200 flex items-center space-x-2 mb-2"
        >
          <div className="w-6 h-6 rounded-full overflow-hidden bg-muted">
            <Image
              src={result?.channelAvatar}
              alt={result?.channelName}
              className="w-full h-full object-cover"
            />
          </div>
          <span>{result?.channelName}</span>
          {result?.isChannelVerified && (
            <Icon name="CheckCircle" size={14} className="text-primary" />
          )}
        </button>
        {result?.description && (
          <p className="text-sm text-text-secondary line-clamp-2">{result?.description}</p>
        )}
      </div>
    </div>
  );
};

export default SearchResultCard;