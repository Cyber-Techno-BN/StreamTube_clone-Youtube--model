import React, { useState } from 'react';

import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const SearchFilters = ({ isOpen, onClose, filters, onFiltersChange }) => {
  const [localFilters, setLocalFilters] = useState(filters);

  const uploadDateOptions = [
    { value: 'any', label: 'Any time' },
    { value: 'hour', label: 'Last hour' },
    { value: 'today', label: 'Today' },
    { value: 'week', label: 'This week' },
    { value: 'month', label: 'This month' },
    { value: 'year', label: 'This year' }
  ];

  const durationOptions = [
    { value: 'any', label: 'Any duration' },
    { value: 'short', label: 'Under 4 minutes' },
    { value: 'medium', label: '4-20 minutes' },
    { value: 'long', label: 'Over 20 minutes' }
  ];

  const typeOptions = [
    { value: 'all', label: 'All results' },
    { value: 'video', label: 'Videos' },
    { value: 'channel', label: 'Channels' },
    { value: 'playlist', label: 'Playlists' }
  ];

  const sortOptions = [
    { value: 'relevance', label: 'Relevance' },
    { value: 'date', label: 'Upload date' },
    { value: 'views', label: 'View count' },
    { value: 'rating', label: 'Rating' }
  ];

  const handleFilterChange = (key, value) => {
    const updatedFilters = { ...localFilters, [key]: value };
    setLocalFilters(updatedFilters);
  };

  const handleApplyFilters = () => {
    onFiltersChange(localFilters);
    onClose();
  };

  const handleClearFilters = () => {
    const clearedFilters = {
      uploadDate: 'any',
      duration: 'any',
      type: 'all',
      sortBy: 'relevance',
      hasSubtitles: false,
      isHD: false,
      isLive: false
    };
    setLocalFilters(clearedFilters);
    onFiltersChange(clearedFilters);
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={onClose} />
      )}
      {/* Filter Panel */}
      <div className={`
        fixed lg:relative top-0 left-0 h-full w-80 bg-background border-r border-border z-50
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        lg:block
      `}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <h3 className="text-lg font-semibold text-foreground">Filters</h3>
            <Button
              variant="ghost"
              size="icon"
              iconName="X"
              onClick={onClose}
              className="lg:hidden"
            />
          </div>

          {/* Filter Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {/* Upload Date */}
            <div>
              <Select
                label="Upload date"
                options={uploadDateOptions}
                value={localFilters?.uploadDate}
                onChange={(value) => handleFilterChange('uploadDate', value)}
              />
            </div>

            {/* Duration */}
            <div>
              <Select
                label="Duration"
                options={durationOptions}
                value={localFilters?.duration}
                onChange={(value) => handleFilterChange('duration', value)}
              />
            </div>

            {/* Type */}
            <div>
              <Select
                label="Type"
                options={typeOptions}
                value={localFilters?.type}
                onChange={(value) => handleFilterChange('type', value)}
              />
            </div>

            {/* Sort By */}
            <div>
              <Select
                label="Sort by"
                options={sortOptions}
                value={localFilters?.sortBy}
                onChange={(value) => handleFilterChange('sortBy', value)}
              />
            </div>

            {/* Advanced Filters */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-foreground">Features</h4>
              
              <Checkbox
                label="Subtitles/CC"
                checked={localFilters?.hasSubtitles}
                onChange={(e) => handleFilterChange('hasSubtitles', e?.target?.checked)}
              />

              <Checkbox
                label="HD (720p+)"
                checked={localFilters?.isHD}
                onChange={(e) => handleFilterChange('isHD', e?.target?.checked)}
              />

              <Checkbox
                label="Live"
                checked={localFilters?.isLive}
                onChange={(e) => handleFilterChange('isLive', e?.target?.checked)}
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="p-4 border-t border-border space-y-2">
            <Button
              variant="default"
              fullWidth
              onClick={handleApplyFilters}
            >
              Apply Filters
            </Button>
            <Button
              variant="outline"
              fullWidth
              onClick={handleClearFilters}
            >
              Clear All
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default SearchFilters;