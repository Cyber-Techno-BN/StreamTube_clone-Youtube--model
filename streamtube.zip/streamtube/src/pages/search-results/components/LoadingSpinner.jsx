import React from 'react';

const LoadingSpinner = ({ size = 'default' }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    default: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  return (
    <div className="flex items-center justify-center p-8">
      <div className={`${sizeClasses?.[size]} border-2 border-text-secondary border-t-primary rounded-full animate-spin`}></div>
    </div>
  );
};

export default LoadingSpinner;