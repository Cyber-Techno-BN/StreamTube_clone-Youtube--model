import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ActiveFilters = ({ filters, onRemoveFilter, onClearAll }) => {
  const getActiveFilters = () => {
    const active = [];
    
    if (filters?.uploadDate !== 'any') {
      const labels = {
        'hour': 'Last hour',
        'today': 'Today',
        'week': 'This week',
        'month': 'This month',
        'year': 'This year'
      };
      active?.push({
        key: 'uploadDate',
        label: labels?.[filters?.uploadDate],
        value: 'any'
      });
    }

    if (filters?.duration !== 'any') {
      const labels = {
        'short': 'Under 4 minutes',
        'medium': '4-20 minutes',
        'long': 'Over 20 minutes'
      };
      active?.push({
        key: 'duration',
        label: labels?.[filters?.duration],
        value: 'any'
      });
    }

    if (filters?.type !== 'all') {
      const labels = {
        'video': 'Videos',
        'channel': 'Channels',
        'playlist': 'Playlists'
      };
      active?.push({
        key: 'type',
        label: labels?.[filters?.type],
        value: 'all'
      });
    }

    if (filters?.sortBy !== 'relevance') {
      const labels = {
        'date': 'Upload date',
        'views': 'View count',
        'rating': 'Rating'
      };
      active?.push({
        key: 'sortBy',
        label: `Sort: ${labels?.[filters?.sortBy]}`,
        value: 'relevance'
      });
    }

    if (filters?.hasSubtitles) {
      active?.push({
        key: 'hasSubtitles',
        label: 'Subtitles/CC',
        value: false
      });
    }

    if (filters?.isHD) {
      active?.push({
        key: 'isHD',
        label: 'HD (720p+)',
        value: false
      });
    }

    if (filters?.isLive) {
      active?.push({
        key: 'isLive',
        label: 'Live',
        value: false
      });
    }

    return active;
  };

  const activeFilters = getActiveFilters();

  if (activeFilters?.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-wrap items-center gap-2 p-4 bg-muted/50 border-b border-border">
      <span className="text-sm font-medium text-foreground">Filters:</span>
      {activeFilters?.map((filter, index) => (
        <div
          key={index}
          className="flex items-center space-x-1 bg-primary/10 text-primary px-3 py-1 rounded-full text-sm"
        >
          <span>{filter?.label}</span>
          <button
            onClick={() => onRemoveFilter(filter?.key, filter?.value)}
            className="hover:bg-primary/20 rounded-full p-0.5 transition-colors duration-200"
          >
            <Icon name="X" size={14} />
          </button>
        </div>
      ))}
      {activeFilters?.length > 1 && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearAll}
          className="text-text-secondary hover:text-foreground"
        >
          Clear all
        </Button>
      )}
    </div>
  );
};

export default ActiveFilters;