import React from 'react';
import Icon from '../../../components/AppIcon';

const SearchSuggestions = ({ query, onSuggestionClick, isVisible }) => {
  const mockSuggestions = [
    `${query} tutorial`,
    `${query} explained`,
    `${query} for beginners`,
    `${query} advanced`,
    `${query} tips and tricks`,
    `${query} review`,
    `${query} vs`,
    `${query} 2024`
  ]?.filter(suggestion => suggestion !== query && query?.length > 0);

  if (!isVisible || mockSuggestions?.length === 0) {
    return null;
  }

  return (
    <div className="absolute top-full left-0 right-0 mt-1 bg-popover border border-border rounded-lg shadow-elevated z-50 animate-slideDown">
      <div className="py-2">
        {mockSuggestions?.slice(0, 6)?.map((suggestion, index) => (
          <button
            key={index}
            onClick={() => onSuggestionClick(suggestion)}
            className="flex items-center w-full px-4 py-2 text-sm text-popover-foreground hover:bg-muted transition-colors duration-200"
          >
            <Icon name="Search" size={16} className="mr-3 text-text-secondary" />
            <span>{suggestion}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default SearchSuggestions;