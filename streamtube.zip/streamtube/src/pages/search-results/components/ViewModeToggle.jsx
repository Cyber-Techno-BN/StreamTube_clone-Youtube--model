import React from 'react';

import Button from '../../../components/ui/Button';

const ViewModeToggle = ({ viewMode, onViewModeChange }) => {
  return (
    <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
      <Button
        variant={viewMode === 'list' ? 'default' : 'ghost'}
        size="sm"
        iconName="List"
        onClick={() => onViewModeChange('list')}
        className="px-3"
      >
        <span className="hidden sm:inline ml-2">List</span>
      </Button>
      <Button
        variant={viewMode === 'grid' ? 'default' : 'ghost'}
        size="sm"
        iconName="Grid3X3"
        onClick={() => onViewModeChange('grid')}
        className="px-3"
      >
        <span className="hidden sm:inline ml-2">Grid</span>
      </Button>
    </div>
  );
};

export default ViewModeToggle;