import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from './Button';

const UploadButton = ({ className = '' }) => {
  const navigate = useNavigate();

  const handleUploadClick = () => {
    navigate('/video-upload-management');
  };

  return (
    <>
      {/* Desktop Upload Button */}
      <div className="hidden md:block">
        <Button
          variant="default"
          onClick={handleUploadClick}
          iconName="Plus"
          iconPosition="left"
          className={`bg-primary hover:bg-primary/90 text-primary-foreground ${className}`}
        >
          Upload
        </Button>
      </div>

      {/* Mobile Upload Button */}
      <div className="md:hidden">
        <Button
          variant="default"
          size="icon"
          iconName="Plus"
          onClick={handleUploadClick}
          className={`bg-primary hover:bg-primary/90 text-primary-foreground ${className}`}
        />
      </div>
    </>
  );
};

export default UploadButton;