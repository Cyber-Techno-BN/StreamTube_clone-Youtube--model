import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';
import Image from '../AppImage';

const UserMenu = ({ isAuthenticated = false, user = null }) => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef?.current && !menuRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMenuToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleMenuItemClick = (path) => {
    navigate(path);
    setIsOpen(false);
  };

  const handleSignOut = () => {
    // Handle sign out logic here
    console.log('Signing out...');
    setIsOpen(false);
  };

  if (!isAuthenticated) {
    return (
      <Button
        variant="outline"
        onClick={() => navigate('/user-authentication-login-register')}
        iconName="User"
        iconPosition="left"
        className="text-sm"
      >
        Sign In
      </Button>
    );
  }

  const menuItems = [
    {
      label: 'Your Channel',
      icon: 'User',
      path: '/channel-profile',
      description: 'View your channel'
    },
    {
      label: 'Settings',
      icon: 'Settings',
      path: '/user-profile-settings',
      description: 'Account settings'
    },
    {
      label: 'Help',
      icon: 'HelpCircle',
      path: '/help',
      description: 'Get support'
    },
    {
      label: 'Feedback',
      icon: 'MessageSquare',
      path: '/feedback',
      description: 'Send feedback'
    }
  ];

  return (
    <div className="relative" ref={menuRef}>
      {/* User Avatar Button */}
      <button
        onClick={handleMenuToggle}
        className="flex items-center space-x-2 p-1 rounded-full hover:bg-muted transition-colors duration-200"
      >
        <div className="w-8 h-8 rounded-full overflow-hidden bg-muted flex items-center justify-center">
          {user?.avatar ? (
            <Image
              src={user?.avatar}
              alt={user?.name || 'User avatar'}
              className="w-full h-full object-cover"
            />
          ) : (
            <Icon name="User" size={18} className="text-text-secondary" />
          )}
        </div>
        <Icon
          name="ChevronDown"
          size={16}
          className={`text-text-secondary transition-transform duration-200 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-64 bg-popover border border-border rounded-lg shadow-elevated z-50 animate-slideDown">
          {/* User Info Header */}
          <div className="px-4 py-3 border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                {user?.avatar ? (
                  <Image
                    src={user?.avatar}
                    alt={user?.name || 'User avatar'}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Icon name="User" size={20} className="text-text-secondary" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-popover-foreground truncate">
                  {user?.name || 'User Name'}
                </p>
                <p className="text-xs text-text-secondary truncate">
                  {user?.email || 'user@example.com'}
                </p>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="py-2">
            {menuItems?.map((item, index) => (
              <button
                key={index}
                onClick={() => handleMenuItemClick(item?.path)}
                className="flex items-center w-full px-4 py-3 text-sm text-popover-foreground hover:bg-muted transition-colors duration-200"
              >
                <Icon name={item?.icon} size={18} className="mr-3 text-text-secondary" />
                <div className="flex-1 text-left">
                  <div className="font-medium">{item?.label}</div>
                  <div className="text-xs text-text-secondary">{item?.description}</div>
                </div>
              </button>
            ))}
          </div>

          {/* Sign Out */}
          <div className="border-t border-border py-2">
            <button
              onClick={handleSignOut}
              className="flex items-center w-full px-4 py-3 text-sm text-popover-foreground hover:bg-muted transition-colors duration-200"
            >
              <Icon name="LogOut" size={18} className="mr-3 text-text-secondary" />
              <span className="font-medium">Sign Out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserMenu;