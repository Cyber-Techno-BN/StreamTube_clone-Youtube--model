import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';
import SearchBar from './SearchBar';
import UserMenu from './UserMenu';
import UploadButton from './UploadButton';

const MainHeader = ({ isAuthenticated = false, user = null }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogoClick = () => {
    navigate('/');
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location?.pathname]);

  const navigationItems = [
    { label: 'Home', path: '/', icon: 'Home' },
    { label: 'Trending', path: '/trending', icon: 'TrendingUp' },
    { label: 'Subscriptions', path: '/subscriptions', icon: 'Users', authRequired: true },
    { label: 'Library', path: '/library', icon: 'BookOpen', authRequired: true },
  ];

  const isActivePath = (path) => {
    if (path === '/') {
      return location?.pathname === '/';
    }
    return location?.pathname?.startsWith(path);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background border-b border-border">
      <div className="flex items-center justify-between h-14 md:h-16 px-4 md:px-6">
        {/* Logo Section */}
        <div className="flex items-center space-x-4">
          <button
            onClick={handleLogoClick}
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity duration-200"
          >
            <div className="w-8 h-8 md:w-10 md:h-10 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="Play" size={20} color="white" />
            </div>
            <span className="text-xl md:text-2xl font-bold text-foreground">
              StreamTube
            </span>
          </button>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-6">
          {navigationItems?.map((item) => {
            if (item?.authRequired && !isAuthenticated) return null;
            
            return (
              <button
                key={item?.path}
                onClick={() => navigate(item?.path)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  isActivePath(item?.path)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-text-secondary hover:text-foreground hover:bg-muted'
                }`}
              >
                <Icon name={item?.icon} size={18} />
                <span>{item?.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Search Bar - Desktop */}
        <div className="hidden md:flex flex-1 max-w-2xl mx-8">
          <SearchBar />
        </div>

        {/* Right Section */}
        <div className="flex items-center space-x-2 md:space-x-4">
          {/* Search Icon - Mobile */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              iconName="Search"
              onClick={() => navigate('/search-results')}
            />
          </div>

          {/* Upload Button */}
          {isAuthenticated && <UploadButton />}

          {/* User Menu */}
          <UserMenu isAuthenticated={isAuthenticated} user={user} />

          {/* Mobile Menu Toggle */}
          <div className="lg:hidden">
            <Button
              variant="ghost"
              size="icon"
              iconName="Menu"
              onClick={toggleMobileMenu}
            />
          </div>
        </div>
      </div>
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-background border-b border-border animate-slideDown">
          <div className="px-4 py-2 space-y-1">
            {/* Mobile Search */}
            <div className="md:hidden mb-4">
              <SearchBar />
            </div>

            {/* Mobile Navigation Items */}
            {navigationItems?.map((item) => {
              if (item?.authRequired && !isAuthenticated) return null;
              
              return (
                <button
                  key={item?.path}
                  onClick={() => navigate(item?.path)}
                  className={`flex items-center space-x-3 w-full px-3 py-3 rounded-lg text-sm font-medium transition-colors duration-200 ${
                    isActivePath(item?.path)
                      ? 'bg-primary text-primary-foreground'
                      : 'text-text-secondary hover:text-foreground hover:bg-muted'
                  }`}
                >
                  <Icon name={item?.icon} size={20} />
                  <span>{item?.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};

export default MainHeader;