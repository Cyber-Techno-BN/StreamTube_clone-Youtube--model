import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import Home from "./pages/home";
import Trending from "./pages/trending";
import Subscriptions from "./pages/subscriptions";
import Library from "./pages/library";
import SearchResults from './pages/search-results';
import ChannelProfile from './pages/channel-profile';
import VideoUploadManagement from './pages/video-upload-management';
import VideoPlayer from './pages/video-player';
import UserProfileSettings from './pages/user-profile-settings';
import UserAuthenticationPage from './pages/user-authentication-login-register';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Home Route - Fixed to use proper Home component */}
        <Route path="/" element={<Home />} />
        <Route path="/trending" element={<Trending />} />
        <Route path="/subscriptions" element={<Subscriptions />} />
        <Route path="/library" element={<Library />} />
        <Route path="/search-results" element={<SearchResults />} />
        <Route path="/channel-profile" element={<ChannelProfile />} />
        <Route path="/video-upload-management" element={<VideoUploadManagement />} />
        <Route path="/video-player" element={<VideoPlayer />} />
        <Route path="/user-profile-settings" element={<UserProfileSettings />} />
        <Route path="/user-authentication-login-register" element={<UserAuthenticationPage />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;